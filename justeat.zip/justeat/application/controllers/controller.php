<?php
class controller extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Mymodel');
		$this->load->helpers(array('url','form'));
		$this->load->library(array('session','upload'));
	}
	function index()
	{
		$res['diss']=$this->Mymodel->viewsnacks();

		$this->load->view('index',$res);
	}
	function login()
	{
		$result['dis']=$this->Mymodel->districtdetailes();
		$this->load->view('login',$result);
	}
	function about()
	{
		$username=$this->session->userdata('username');
		$result['dis']=$this->Mymodel->disuser($username);

		$this->load->view('reg_about',$result);

	}
	function uabout()
	{

		$this->load->view('about');

	}
	function bookeditems()
	{
		$username=$this->session->userdata('username');
		$customerid=$this->session->userdata('id');
		$resultarray=array('diss'=>$this->Mymodel->displaybookeditems($customerid),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('bookeditems',$resultarray);
	}

	//itemsfunctiion
	function snacks()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->viewsnacks(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Biscuits()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Biscuits(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Cookies()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Cookies(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Straws()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Straws(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Olives()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Olives(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Gherkins()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Gherkins(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Sundried()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Sundried(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Chips ()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Chips(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Dryfruits()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Dryfruits(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Dryseeds()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Dryseeds(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function DrySnacks()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->DrySnacks(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Funsize()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Funsize(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Milk()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Milk(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Fudge()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Fudge(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}
	function Bouquettes()
	{
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->Bouquettes(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('product',$resultarray);

	}




//viewproductdetailes
	 function view_singleproduct()
	{
		$username=$this->session->userdata('username');
		$itemid=$this->input->post('itemid');
		$resultarray=array('diss'=>$this->Mymodel->view_singleproduct($itemid),'dis'=>$this->Mymodel->disuser($username));

		$this->load->view('viewproduct',$resultarray);

	}
	function contact()
	{
		$username=$this->session->userdata('username');
		$result['dis']=$this->Mymodel->disuser($username);

		$this->load->view('reg_mail',$result);
	}
	function ucontact()
	{


		$this->load->view('mail');
	}

	function userhome()
	{
		$username=$this->session->userdata('username');
		$result=array('diss'=>$this->Mymodel->viewsnacks(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('reguser_index',$result);
	}
	function checkout()
	{
		  $prodid=$this->input->post('pid');

		$username=$this->session->userdata('username');
		$customerid=$this->session->userdata('id');
		$resultarray=array('diss'=>$this->Mymodel->displaycart($customerid),'dis'=>$this->Mymodel->disuser($username),'id'=>$this->Mymodel->prodprice($prodid));
		$this->load->view('checkout',$resultarray);

	}
	function payment()
	{
		$username=$this->session->userdata('username');
		$result['dis']=$this->Mymodel->disuser($username);
		$this->load->view('paymentdetailes',$result);
	}
	//admin
	function admin()
	{
		$uname=$this->session->userdata('username');
		$result['dis']=$this->Mymodel-> admindisuser($uname);

		$this->load->view('admin_index',$result);
	}
	function admintable()
	{
		$this->load->view('admin_tables');
	}
	function adminaddqualitychecker()
	{
		$result['dis']=$this->Mymodel->districtdetailes();
		$this->load->view('admin_addqualitychecker',$result);
	}
	function adminadddeliverer()
	{
		$result['dis']=$this->Mymodel->districtdetailes();
		$this->load->view('admin_adddeliverer',$result);
	}




	function adminreports()
	{
		$this->load->view('admin_reports');
	}
	//admin listseller
	function displayseller()
	{
		$display['dis']=$this->Mymodel->displayseller();
		$this->load->view('admin_sellerlist',$display);

	}
	//admin approvedseller
	function approvedseller()
	{
		$display['dis']=$this->Mymodel->approvedseller();
		$this->load->view('admin_approvedseller',$display);

	}
	//admin approveseller
	function approveseller()
	{
		$display['dis']=$this->Mymodel->approveseller();
		$this->load->view('admin_approveseller',$display);

	}
	//admin viewuser
	function adminviewusers()
	{
		$display['dis']=$this->Mymodel->displayuser();
		$this->load->view('admin_viewusers',$display);
	}
	//admin view qualitychecker
	function adminviewquality()
	{
		$display['dis']=$this->Mymodel->adminviewquality();
		$this->load->view('admin_viewusers',$display);
	}
	//admin view deliverer
	function adminviewdeliverer()
	{
		$display['dis']=$this->Mymodel->adminviewdeliverer();
		$this->load->view('admin_viewusers',$display);
	}
	//item detailes
	function adminitemdetailes()
	{

		$display['dis']=$this->Mymodel->adminitemdetailes();
		$this->load->view('admin_itemdetailes',$display);
	}
	//blockitemdetailes
	function itemdetailes()
	{
		$itemid=$this->input->post('itemblock');
		$itemstatus=$this->input->post('blockstatus');

		if($itemstatus==0)
		{
			$status=1;
			$this->Mymodel->blockitem($itemid,$status);
			$display['dis']=$this->Mymodel->adminitemdetailes();
			$this->load->view('admin_itemdetailes',$display);
		}
		else
		{
			$status=0;
			$this->Mymodel->blockitem($itemid,$status);
			$display['dis']=$this->Mymodel->adminitemdetailes();
			$this->load->view('admin_itemdetailes',$display);
		}



	}


	//approveselleraction
	function approveselleraction()
	{
		$lid=$this->input->post('blockid');
		$blockstatus=$this->input->post('blockstatus');

		if($blockstatus == 0)
		{
			$status=1;
			$this->Mymodel->approveselleraction($lid,$status);

			$display['dis']=$this->Mymodel->approveseller();

		   $this->load->view('admin_approveseller',$display);
		}



	}
	function admincategorydetailes()
	{
		$result['dis']=$this->Mymodel->admincategorydetailes();
		//$categoryname=$row->category_name;

		$this->load->view('admin_categorydetailes',$result);
	}
	function categoryapprove()
	{
		$categoryid=$this->input->post('categoryblock');
		$categorystatus=$this->input->post('blockstatus');
		if($categorystatus==0)
		{
			$status=1;
			$this->Mymodel->categoryapprove($categoryid,$status);
			$result['dis']=$this->Mymodel->admincategorydetailes();

			$this->load->view('admin_categorydetailes',$result);
		}
		else
		{
			$status=0;
			$this->Mymodel->categoryapprove($categoryid,$status);
			$result['dis']=$this->Mymodel->admincategorydetailes();
			$this->load->view('admin_categorydetailes',$result);
		}

	}
	//subcategoryapprove
	function adminsubcategorydetailes()
	{
		$result['dis']=$this->Mymodel->adminsubcategorydetailes();
		//$categoryname=$row->category_name;

		$this->load->view('admin_subcategorydetailes',$result);
	}
	 function subcategoryapprove()
	{
		$categoryid=$this->input->post('categoryblock');
		$categorystatus=$this->input->post('blockstatus');
		if($categorystatus==0)
		{
			$status=1;
			$this->Mymodel->subcategoryapprove($categoryid,$status);
			$result['dis']=$this->Mymodel->adminsubcategorydetailes();

			$this->load->view('admin_subcategorydetailes',$result);
		}
		else
		{
			$status=0;
			$this->Mymodel->subcategoryapprove($categoryid,$status);
			$result['dis']=$this->Mymodel->adminsubcategorydetailes();
			$this->load->view('admin_subcategorydetailes',$result);
		}

	}


	//quality
	function quality_home()
	{
		$this->load->view('qualitycheck_home');
	}
	//seller
	function seller_home()
	{
		$username=$this->session->userdata('username');
		$result['dis']=$this->Mymodel->disuser($username);
		//$result['seller']=$this->Mymodel->disuserseller($uname);
		$this->load->view('seller_home',$result);

	}
	//seller profile view
	function seller_profile()
	{

		$username=$this->session->userdata('username');

		$resultarray=array("dis"=>$this->Mymodel->disuser($username),"diss"=>$this->Mymodel->districtdetailes());
		$this->load->view('seller_profile',$resultarray);
		//$resulta['dis']=$this->Mymodel->districtdetailes();
		//$this->load->view('seller_profile',$resulta);
	}
	//seller add item
	function seller_additem()
	{
		$itemid=$this->input->post('itemid');
		$username=$this->session->userdata('username');
		$resultarray=array("dis"=>$this->Mymodel->categoryname(),"dissub"=>$this->Mymodel->subcategoryname(),"diss"=>$this->Mymodel->disuser($username),"disimage"=>$this->Mymodel->itemimage($itemid));
			$this->load->view('seller_additem',$resultarray);
	}
	//seller add category
	function seller_addcategory()
	{
		$username=$this->session->userdata('username');
		$result=array("diss"=>$this->Mymodel->disuser($username),"dis"=>$this->Mymodel->categoryname());
		$this->load->view('seller_addcategory',$result);
	}

	//update sellerinfo
	function sellerinfo()
	{



		$emaill=$this->input->post('emaila');
		$u_name =$this->input->post('name');
		$u_phone =$this->input->post('phone');
		$u_district=$this->input->post('districta');
		$u_address1 =$this->input->post('address1');
		$u_address2=$this->input->post('address2');
		$u_city =$this->input->post('city');
		$u_pincode=$this->input->post('pincode');
		$u_pancard=$this->input->post('pancard');
		$u_licence=$this->input->post('licence');
		$u_experience=$this->input->post('experience');
		$image =  time().$_FILES['sellerprofile']['name'];
	move_uploaded_file($_FILES['sellerprofile']['tmp_name'],"../justeat/images/profile/".$image);

		$username=$this->session->userdata('username');

		//$result['dis']=$this->Mymodel->disuser($uname);


		$logid=$this->Mymodel->updateseller($u_name,$username,$u_address1,$u_address2,$u_city,$u_district,$u_pincode,$u_pancard,$u_licence,$u_experience,$image);

		$resultarray=array("dis"=>$this->Mymodel->disuser($username),"diss"=>$this->Mymodel->districtdetailes());
		$this->load->view('seller_profile',$resultarray);


	}
	//seller add item
	function additem()
	{

		$itemstock=$this->input->post('stock');
		$itemname=$this->input->post('item_name');
		$category=$this->input->post('category');
		$subcategory=$this->input->post('subcategory');
		$price=$this->input->post('price');
		$quantity=$this->input->post('quantity');
		$measure=$this->input->post('measure');
		$date=$this->input->post('date');
		$discription=$this->input->post('discription');
		$itemid=$this->input->post('itemid');

		$lid=$this->session->userdata('id');




		$result['item']=$this->Mymodel->checkitem($lid,$itemname,$category,$subcategory,$price);
		if(!$result['item'])
		{
			$folderPath = "../justeat/images/products/";
			$image =  time().$_FILES['itemimage']['name'];
			move_uploaded_file($_FILES['itemimage']['tmp_name'],$folderPath.$image);

			//$imagea= $_FILES['itemimage']['name'];

			 //$fileNewName = time();

			$sourceProperties = getimagesize($folderPath.$image);
		  	$ext = pathinfo($_FILES['itemimage']['name'], PATHINFO_EXTENSION);
		  	 $imageType = $sourceProperties[2];

		  switch ($imageType) {


              case IMAGETYPE_PNG:
                $imageResourceId = imagecreatefrompng($folderPath.$image);
                $targetLayer = $this->imageResize($imageResourceId,$sourceProperties[0],$sourceProperties[1]);
                imagepng($targetLayer,$folderPath.$image);
                break;


            case IMAGETYPE_GIF:
                $imageResourceId = imagecreatefromgif($folderPath.$image);
                $targetLayer = $this->imageResize($imageResourceId,$sourceProperties[0],$sourceProperties[1]);
                imagegif($targetLayer,$folderPath.$image);
                break;


            case IMAGETYPE_JPEG:
                $imageResourceId = imagecreatefromjpeg($folderPath.$image);
                $targetLayer =$this->imageResize($imageResourceId,$sourceProperties[0],$sourceProperties[1]);
                imagejpeg($targetLayer,$folderPath.$image);
                break;


            default:
                echo "Invalid Image type.";
                exit;
                break;

			 }

			//$handle = $_FILES['itemimage']['name'];


		$itemimageid=$this->input->post('itemimageid');

		//$userdataa=array('category_name'=>$category,'status'=>1);
			//$aid=$this->Mymodel->insertcategory($userdataa);
			$uname=$this->session->userdata('username');
			$logid=$this->session->userdata('id');
		$userdatab=array('ilogin_id'=>$logid,'item_name'=>$itemname,'category_id'=>$category,'subcategory_id'=>$subcategory,'price'=>$price,'quantity'=>$quantity,'measurement'=>$measure,'stock'=>$itemstock,'date'=>$date,'discription'=>$discription,'photo'=>$image,'item_status'=>1);
		$itemid=$this->Mymodel->insertitem($userdatab);
		$username=$this->session->userdata('username');
		$this->session->set_flashdata('response',"item added");
		$resultarray=array("dis"=>$this->Mymodel->categoryname(),"dissub"=>$this->Mymodel->subcategoryname(),"diss"=>$this->Mymodel->disuser($username),"disimage"=>$this->Mymodel->itemimage($itemid));
		$this->load->view('seller_additem',$resultarray);
		}
		else
		{
			//$qry['']=$this->Mymodel->checkitem($lid,$itemname,$category,$price,$q,$discription);

		$username=$this->session->userdata('username');
			$this->session->set_flashdata('response',"item already added");
			$resultarray=array("dis"=>$this->Mymodel->categoryname(),"dissub"=>$this->Mymodel->subcategoryname(),"diss"=>$this->Mymodel->disuser($username),"disimage"=>$this->Mymodel->itemimage($itemid));
			$this->load->view('seller_additem',$resultarray);
		}

	}
	function imageResize($imageResourceId,$width,$height)
			{


		$targetWidth =200;
		$targetHeight =200;


		$targetLayer=imagecreatetruecolor($targetWidth,$targetHeight);
		imagecopyresampled($targetLayer,$imageResourceId,0,0,0,0,$targetWidth,$targetHeight, $width,$height);


		return $targetLayer;
			}


	function seller_viewaddeditem()
	{
		$usename=$this->session->userdata('id');
		$username=$this->session->userdata('username');
		$resultarray=array("diss"=>$this->Mymodel->disuser($username),"disitem"=>$this->Mymodel->selleritemdetailes($usename));
		$this->load->view('seller_viewitemdetails',$resultarray);
	}
	function edititem()
	{
		$username=$this->session->userdata('username');
		$itemid=$this->input->post('itemblock');
		$resultarray=array("dis"=>$this->Mymodel->categoryname(),"dissub"=>$this->Mymodel->subcategoryname(),"diss"=>$this->Mymodel->disuser($username),"disdata"=>$this->Mymodel->edititem($itemid));
		//echo $c;
		$this->load->view('updateitem',$resultarray);

	}
	function updateitem()
	{
		$itemstock=$this->input->post('stock');
		//$itemname=$this->input->post('item_name');
		//$category=$this->input->post('category');
		//$subcategory=$this->input->post('subcategory');
		$price=$this->input->post('price');
		$quantity=$this->input->post('quantity');
		$measure=$this->input->post('measure');
		$date=$this->input->post('date');
		$discription=$this->input->post('discription');
		$itemid=$this->input->post('itemid');

		$lid=$this->session->userdata('id');

		$image =  time().$_FILES['itemimage']['name'];
	move_uploaded_file($_FILES['itemimage']['tmp_name'],"../justeat/images/products/".$image);

		$itemimageid=$this->input->post('itemimage');

		//$userdataa=array('category_name'=>$category,'status'=>1);
			//$aid=$this->Mymodel->insertcategory($userdataa);
			$username=$this->session->userdata('username');
			$logid=$this->session->userdata('id');


			$this->session->set_flashdata('responseupdate',"item updated");
			$resultarray=array($log=$this->Mymodel->updateitem($itemstock,$price,$quantity,$measure,$date,$discription,$image,$itemid),"dis"=>$this->Mymodel->categoryname(),"dissub"=>$this->Mymodel->subcategoryname(),"diss"=>$this->Mymodel->disuser($username),"disdata"=>$this->Mymodel->edititem($itemid));
		//echo $c;
		$this->load->view('updateitem',$resultarray);

	}

	//add category
	function addcategory()
	{
		$username=$this->session->userdata('username');
		$categoryname=$this->input->post('newcatogory');
		//$lid=$this->session->userdata('id');
		$sid=$this->session->userdata('id');
		$result['id']=$this->Mymodel->checkcategory($categoryname);
		if(!$result['id'])
		{
		$category=array('category_name'=>$categoryname,'s_id'=>$sid,'c_status'=>0);
		$this->Mymodel->addcategory($category);
		//$this->session->set_userdata('categorymsg',"Category Added");
		$this->session->set_flashdata('responsx',"Category added");

		$result=array("dis"=>$this->Mymodel->categoryname(),"diss"=>$this->Mymodel->disuser($username));
		$this->load->view('seller_addcategory',$result);
		}
		else
		{
			$this->session->set_flashdata('responsx',"Category already exists");
		$result=array("dis"=>$this->Mymodel->categoryname(),"diss"=>$this->Mymodel->disuser($username));
		$this->load->view('seller_addcategory',$result);
		}

	}
	function addsubcategory()
	{
		$username=$this->session->userdata('username');
		$subcategoryname=$this->input->post('newcatogory');
		$categoryid=$this->input->post('category');
		//$lid=$this->session->userdata('id');
		$sid=$this->session->userdata('id');
		$result['id']=$this->Mymodel->checksubcategory($subcategoryname);
		if(!$result['id'])
		{
		$category=array('subcategory_name'=>$subcategoryname,'c_id'=>$categoryid,'s_id'=>$sid,'sub_status'=>0);
		$this->Mymodel->addsubcategory($category);
		//$this->session->set_userdata('categorymsg',"Category Added");
		$this->session->set_flashdata('responsx',"Sub Category added");

		$result=array("dis"=>$this->Mymodel->categoryname(),"diss"=>$this->Mymodel->disuser($username));
		$this->load->view('seller_addcategory',$result);
		}
		else
		{
			$this->session->set_flashdata('responsx',"Sub Category already exists");
		$result=array("dis"=>$this->Mymodel->categoryname(),"diss"=>$this->Mymodel->disuser($username));
		$this->load->view('seller_addcategory',$result);
		}

	}
	//deliverer
	function deliverer_home()
	{
		$this->load->view('deliverer_home');
	}
	//user registration
	function insertuser()
	{

		$u_type=$this->input->post('type');
		$u_name =$this->input->post('name');
		$u_phone =$this->input->post('phone');
		$u_email =$this->input->post('email');
		$u_address1 =$this->input->post('address1');
		$u_address2=$this->input->post('address2');
		$u_city =$this->input->post('city');
		$u_district=$this->input->post('district');
		$u_pincode=$this->input->post('pincode');
		//$u_pancard=$this->input->post('pancard');
		$u_password=$this->input->post('password');
		$u_cpassword=$this->input->post('cpassword');


		$result['id']=$this->Mymodel->checkreguser($u_email);
		if(!$result['id'])
		{

			$userdatab=array('address1'=>$u_address1,'address2'=>$u_address2,'city'=>$u_city,'district_id'=>$u_district,'pincode'=>$u_pincode,'pancard'=>'','status'=>1);
			$aid=$this->Mymodel->insertaddress($userdatab);
			$userdatac=array('name'=>$u_name,'rphone'=>$u_phone,'address_id'=>$aid,'status'=>1);
			$rid=$this->Mymodel->insertreg($userdatac);
			$userdatad=array('email'=>$u_email,'password'=>$u_password,'user_id'=>$rid,'type'=>$u_type,'status'=>0);
			$lid=$this->Mymodel->insertlogin($userdatad);


			$sellerinfo=array('slogin_id'=>$lid,'licence_number'=>'NULL','experience'=>'NULL','image'=>'NULL','s_status'=>0);
				$this->Mymodel->insertseller($sellerinfo);
				$this->session->set_flashdata('responsa',"Registration Succesfull..!");
				$result['dis']=$this->Mymodel->districtdetailes();
				$this->load->view('login',$result);
		}
		else
		{
			$this->session->set_flashdata('responsa',"User already exists..!");
			$result['dis']=$this->Mymodel->districtdetailes();
				$this->load->view('login',$result);
		}
	}
	//user login
	function ulogin()
	{
		$username=$this->input->post('username');
		$password=$this->input->post('password');
		$loginresult['login']=$this->Mymodel->loguser($username,$password);
		if(!$loginresult['login'])
		{
			$this->session->set_flashdata('responsec',"Invalid login..!");
			//$result['dis']=$this->Mymodel->districtdetailes();
		$this->load->view('login');
		}
		else
		{
			foreach($loginresult['login'] as $row)
			{
				$lid=$row->login_id;
				$username=$row->email;
				$password=$row->password;
				$type=$row->type;
				$status=$row->status;

				if($type=='1')
					{
						 $this->session->set_userdata('id',$lid);
						$this->session->set_userdata('username',$username);
						$this->session->set_userdata('password',$password);


						$result['dis']=$this->Mymodel-> admindisuser($username);

						$this->load->view('admin_index',$result);
					}
				else if($type=="Shopper")
					{
						$this->session->set_userdata('id',$lid);
						$this->session->set_userdata('username',$username);
						$this->session->set_userdata('password',$password);

						$result=array('diss'=>$this->Mymodel->viewsnacks(),'dis'=>$this->Mymodel->disuser($username));

						$this->load->view('reguser_index',$result);
					}
					else if($type=="Seller")
					{
						$this->session->set_userdata('id',$lid);
						$this->session->set_userdata('username',$username);
						$this->session->set_userdata('password',$password);

						$result['dis']=$this->Mymodel->disuser($username);

						$this->load->view('seller_home',$result);

					}
					else if($type=="QChecker")
					{
						$this->load->view('qualitycheck_home');

					}
					else if($type=="Deliverer")
					{
						$this->load->view('deliverer_home');

					}

			}
		}
	}
	//insert quality checker
	function insertqualitychecker()
	{
		$u_name =$this->input->post('name');
		$u_phone =$this->input->post('mobilenumber');
		$u_email =$this->input->post('email');
		$u_address1 =$this->input->post('address1');
		$u_address2=$this->input->post('address2');
		$u_district=$this->input->post('district');
		$u_password=$this->input->post('password');


		$result['id']=$this->Mymodel->checkreguser($u_email);

		if(!$result['id'])
		{

		$qaddress=array('address1'=>$u_address1,'address2'=>$u_address2,'city'=>'','district_id'=>$u_district,'pincode'=>'','pancard'=>'','status'=>1);
		$qaid=$this->Mymodel->insertaddress($qaddress);
		$quser=array('name'=>$u_name,'rphone'=>$u_phone,'address_id'=>$qaid,'status'=>1);
		$qrid=$this->Mymodel->insertreg($quser);
		$qlogin=array('email'=>$u_email,'password'=>$u_password,'user_id'=>$qrid,'type'=>"QChecker",'status'=>1);
		$qlid=$this->Mymodel->insertlogin($qlogin);
		$this->session->set_flashdata('response',"Registration Succesfull..!");
		$result['dis']=$this->Mymodel->districtdetailes();
		$this->load->view('admin_addqualitychecker',$result);
		}
		else
		{
			$this->session->set_flashdata('response',"Quality Checker already exist...!!");
			$result['dis']=$this->Mymodel->districtdetailes();
			$this->load->view('admin_addqualitychecker',$result);
		}
	}
	//insert Deliverer
	function insertdeliverer()
	{
		$u_name =$this->input->post('name');
		$u_phone =$this->input->post('mobilenumber');
		$u_email =$this->input->post('email');
		$u_address1 =$this->input->post('address1');
		$u_address2=$this->input->post('address2');
		$u_district=$this->input->post('district');
		$u_password=$this->input->post('password');


		$result['id']=$this->Mymodel->checkreguser($u_email);

		if(!$result['id'])
		{

		$qaddress=array('address1'=>$u_address1,'address2'=>$u_address2,'city'=>'','district_id'=>$u_district,'pincode'=>'','pancard'=>'','status'=>1);
		$qaid=$this->Mymodel->insertaddress($qaddress);
		$quser=array('name'=>$u_name,'rphone'=>$u_phone,'address_id'=>$qaid,'status'=>1);
		$qrid=$this->Mymodel->insertreg($quser);
		$qlogin=array('email'=>$u_email,'password'=>$u_password,'user_id'=>$qrid,'type'=>"Deliverer",'status'=>1);
		$qlid=$this->Mymodel->insertlogin($qlogin);
		$result['dis']=$this->Mymodel->districtdetailes();
		$this->load->view('admin_adddeliverer',$result);
		}
		else
		{
			echo "Quality Checker already exist...!!";
			$result['dis']=$this->Mymodel->districtdetailes();
			$this->load->view('admin_adddeliverer',$result);
		}
	}


	//logout
	function logout()
	{
		$this->session->sess_destroy();
		redirect('controller/index');
	}
	function sessionin()
	{
		$username=$this->session->userdata('username');
		$password=$this->session->userdata('password');
		$login['result']=$this->Mymodel->loguser($username,$password);
		if($login['result'])
		{
			return(1);
		}
		else
		{
			return(0);
		}
	}
	//reguser


	function itemviewmore()
	{
		$itemid=$this->input->post('itemid');
		$this->Mymodel->itemviewmore($itemid);
	}

	//dropdownajax seller add item
	function getsubcategory($catogryid)
	{

		//$catogryid=$this->input->post('category');
		$data=$this->Mymodel->getsubcategory($catogryid);

		echo json_encode($data);


		// $this->load->view('controole/ajax_get_state',$data);
	}
	function addtocart()
	{
		$cart=$this->input->post('submit');
		$buy=$this->input->post('buynow');
		if(isset($cart))
		{
		$rating=$this->input->post('rating');
		$booking_date=$this->input->post('date');
		//$numberofpackets=$this->input->post('number_ofpackets');
		$itemid=$this->input->post('itemid');
		$username=$this->session->userdata('username');
		$customerid=$this->session->userdata('id');
		$booking_status=0;
		$result=$this->Mymodel->checkorder($itemid);
		if(!$result)
		{
		$bookingdata=array('cust_id'=>$customerid,'product_id'=>$itemid,'date_ofbooking'=>$booking_date,'number_ofpacket'=>'1','rating'=>$rating,'d_address'=>' ','ordernumber'=>' ','booking_status'=>$booking_status);
		$resultarray=array('cart'=>$this->Mymodel->addtocart($bookingdata),'diss'=>$this->Mymodel->displaycart($customerid),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('checkout',$resultarray);
		}
		else
		{
			$bookingdata=array('cust_id'=>$customerid,'product_id'=>$itemid,'date_ofbooking'=>$booking_date,'rating'=>$rating,'booking_status'=>$booking_status);
		$resultarray=array('diss'=>$this->Mymodel->displaycart($customerid),'dis'=>$this->Mymodel->disuser($username));
		$this->session->set_flashdata('response',"Item  already exist in cart...!!");
		$this->load->view('checkout',$resultarray);
		}
	}
	if(isset($buy))
	{
	$bid=$this->input->post('bid');
	$rating=$this->input->post('rating');
	$booking_date=$this->input->post('date');
	//$numberofpackets=$this->input->post('number_ofpackets');
	$itemid=$this->input->post('itemid');
	$username=$this->session->userdata('username');
	$customerid=$this->session->userdata('id');
	$booking_status=0;
	//$result=$this->Mymodel->checkorder($itemid);

	$name=$this->input->post('name');

	$add1=$this->input->post('add1');
	$add2=$this->input->post('add2');
	$city=$this->input->post('city');
	$dis=$this->input->post('dis');
	$pin=$this->input->post('pin');
	$data=$name.' ,'.$add1.' ,'.$add2.' ,'.$city.' ,'.$dis.' ,'.$pin;

	$bookingdata=array('cust_id'=>$customerid,'product_id'=>$itemid,'date_ofbooking'=>$booking_date,'number_ofpacket'=>'1','rating'=>$rating,'d_address'=>' ','ordernumber'=>' ','booking_status'=>$booking_status);

	$resultarray=array('cart'=>$this->Mymodel->addtocart($bookingdata),'dissss'=>$this->Mymodel->useraddress($customerid),'diss'=>$this->Mymodel->bookitem(),'dis'=>$this->Mymodel->disuser($username),'disss'=>$this->Mymodel->useraddress($customerid));

	$this->load->view('paymentsteps',$resultarray);
	}

	}
	function buynow()
	{


	}

	function removebooking()
	{
		$remove=$this->input->post('remove');
		if(isset($remove))
		{


		$bookingid=$this->input->post('bkid');

		$this->Mymodel->removebooking($bookingid);
		$customerid=$this->session->userdata('id');
		$username=$this->session->userdata('username');
		$resultarray=array('diss'=>$this->Mymodel->displaycart($customerid),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('checkout',$resultarray);
	}
	}

	function booking_confirm()
	{
		$ss=$this->input->post('updatesubmit');
		if(isset($ss))
		{
		$username=$this->session->userdata('username');
		$cust_id=$this->session->userdata('id');
		$userid=$this->session->userdata('id');
		$bid=$this->input->post('bid');
		$cid=$this->input->post('cid');
		//$cust_id=$this->input->post('custid');


		//$totalamnt=$this->input->post('totalamnt');
		//echo $totalamnt;

		$data=$this->input->post('qty');
		$d=array('number_ofpacket'=>$data);
		$this->Mymodel->updateqty($cid,$d,$cust_id);
		//echo $data;
		$resultarray=array('diss'=>$this->Mymodel->bookitem(),'dis'=>$this->Mymodel->disuser($username),'dissss'=>$this->Mymodel->userdeliveryaddress($bid),'disss'=>$this->Mymodel->useraddress($userid));

		$this->load->view('paymentsteps',$resultarray);



}

	}
	function scount($a)
	{
		$countlist=$this->Mymodel->scount($a);
		return $countlist;
	}
	function categorycount($a)
	{
		$countlist=$this->Mymodel->categorycount($a);
		return $countlist;
	}
	function subcategorycount($a)
	{
		$countlist=$this->Mymodel->subcategorycount($a);
		return $countlist;
	}
	function customercount($a)
	{
		$countlist=$this->Mymodel->customercount($a);
		return $countlist;
	}
	function itemcount($username)
	{
		$itemcount=$this->Mymodel->itemcount($username);
		return $itemcount;
	}
	function wcategorycount($userid,$a)
	{
		$countlist=$this->Mymodel->wcategorycount($userid,$a);
		return $countlist;
	}
	function wsubcategorycount($userid,$a)
	{
		$countlist=$this->Mymodel->wsubcategorycount($userid,$a);
		return $countlist;
	}
	function cart($username,$a)
	{
		$countlist=$this->Mymodel->cart($username,$a);
		return $countlist;
	}
	function Order($username,$a)
	{
		$countlist=$this->Mymodel->Order($username,$a);
		return $countlist;
	}
	function updatebookingaddrres()
	{
	$submitaddr=$this->input->post('submitaddr');
if(isset($submitaddr))
{
		$bid=$this->input->post('bid[]');
		$username=$this->session->userdata('username');
		$userid=$this->session->userdata('id');
	$name=$this->input->post('name');

	$add1=$this->input->post('add1');
	$add2=$this->input->post('add2');
	$city=$this->input->post('city');
	$dis=$this->input->post('dis');
	$pin=$this->input->post('pin');
	$data=$name.' ,'.$add1.' ,'.$add2.' ,'.$city.' ,'.$dis.' ,'.$pin;
	$cid=$this->input->post('cid');


	foreach ($bid as $bid)
		{

		$data=array('d_address'=>$data);
        $this->Mymodel->updatebookingaddrres($data,$bid);
		$resultarray=array('diss'=>$this->Mymodel->bookitem(),'dis'=>$this->Mymodel->disuser($username),'dissss'=>$this->Mymodel->userdeliveryaddress($bid),'disss'=>$this->Mymodel->useraddress($userid));

		$this->load->view('paymentsteps',$resultarray);
		}
	//


	}
	}
	//	$total=$qty*$prodprice;
//echo $total;

	//$this->Mymodel->updatebookingtotal($bid,$total);






	function forgotpwd()
	{

		$this->load->view('forgotpassword');
	}
 function ForgotPassword()
{
    $email = $this->input->post('email');
    $findemail = $this->Mymodel->ForgotPassword($email);
    if ($findemail) {
        $this->Mymodel->sendpassword($findemail);
    } else {
        echo "<script>alert(' $email not found, please enter correct email id')</script>";
        redirect(base_url() . 'controller/index', 'refresh');
    }
}
function paymenta()
{
$bank=$this->input->post('banktype');
$random=rand();

$prodid=$this->input->post('prodid[]');
$bkid=$this->input->post('bkid');
	if(isset($bank))
	{
	$isum=$this->input->post('isum');
	$card=$this->input->post('cardnumber');
	$month=$this->input->post('month');
	$year=$this->input->post('year');
	$cvv=$this->input->post('cardCVV');
	$name=$this->input->post('holdername');



$data=array('bank_name'=>$bank,'name'=>$name,'account_number'=>$card,'cvv'=>$cvv,'month'=>$month,'year'=>$year);
	$data['id']=$this->Mymodel->bankverification($data);
	if($data['id'])
	{
		foreach ($data['id'] as $row)
		{
			$bankid=$row->bank_id;
			$amount=$row->balance;
			//echo $amount;
			if($amount > $isum)
			{
				//echo $isum;
				$balance=$amount-$isum;
				//echo $balance;
				$count1['dis']=$this->Mymodel->select_id($bkid);

				foreach ($count1['dis'] as $row)
				{
					$bid=$row->booking_id;
					$bs_id=$row->product_id;
					$cust_id=$row->cust_id;
					$ordernumber=$row->ordernumber;
					$itemqty=$row->number_ofpacket;
					$this->Mymodel->updatestatus($ordernumber);
					$this->Mymodel->updatebankbalance($balance,$bankid);
					$res['dis']=$this->Mymodel->selectproduct($bs_id);
					foreach($res['dis'] as $row)
					{

						$stock=$row->stock;
						$prod=$row->item_id;

						if($stock > $itemqty)
						{



              				$updatedstock=$stock-$itemqty;
							$this->Mymodel->updatestock($updatedstock,$prod);
							echo "<script>alert('updated')</script>";
							$this->success();
						}
						else {
							echo "<script>alert('No Stock')</script>";
							$this->success();
						}

					}


					echo "<script>alert('Payment Succesfull')</script>";
						$this->success();
				}

			}
			else {
				echo "<script>alert('Insufficient Balance in Account')</script>";
				$this->insufficient();
			}
		}
	}
		else {
				echo "<script>alert('Payment card detailes incorrect')</script>";
				$this->carderror();
		}
	}
	else {

	$resultarray=array('diss'=>$this->Mymodel->bookitem(),'dis'=>$this->Mymodel->disuser($username),'dissss'=>$this->Mymodel->userdeliveryaddress($bid),'disss'=>$this->Mymodel->useraddress($userid));
	$this->load->view('paymentsteps',$resultarray);
	}
}
function success()
{
	$username=$this->session->userdata('username');
		$result=array('diss'=>$this->Mymodel->viewsnacks(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('reguser_index',$result);
}
function insufficient()
{
	$username=$this->session->userdata('username');
		$result=array('diss'=>$this->Mymodel->viewsnacks(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('reguser_index',$result);
}
function carderror()
{
	$username=$this->session->userdata('username');
	$resultarray=array('diss'=>$this->Mymodel->bookitem(),'dis'=>$this->Mymodel->disuser($username));
	$this->load->view('paymentdetailes',$resultarray);
}
function updateorder()
{

	$bid=$this->input->post('bid');
		$username=$this->session->userdata('username');
		$userid=$this->session->userdata('id');
	$confirmsubmit=$this->input->post('confirmsubmit');

	if(isset($confirmsubmit))
	{

		$cust_id=$this->input->post('custid');
		$bkid=$this->input->post('bbid[]');
		$rand=rand();
		foreach ($bkid as $bkid)
		{

		$data = array(
                'ordernumber' => $rand);
        $this->db->where('booking_id', $bkid);
        $this->db->update('tbl_booking', $data);

		}

		$resultarray=array('diss'=>$this->Mymodel->bookitem(),'dis'=>$this->Mymodel->disuser($username));
		$this->load->view('paymentdetailes',$resultarray);
	}
	else
	{
		echo "ddd";
	}

}
function select (){

    //$this->load->model('Login_model');

    if(isset($_GET ['search']) && !empty($_GET['search'])) {

        $search= $_GET[ 'search'];
        //$this->load->model('Login_model');
        //$result['diss']=$this->Mymodel->selectorganizer($search);
$username=$this->session->userdata('username');


          //  $data['diss']=$result;
						$re=array('dis'=>$this->Mymodel->disuser($username),'diss'=>$this->Mymodel->selectorganizer($search),'diss'=>$this->Mymodel->selectorganizercategory($search));
             $this->load->view('booking_confirm',$re);

    }
}
function userselect (){

    //$this->load->model('Login_model');

    if(isset($_GET ['search']) && !empty($_GET['search'])) {

        $search= $_GET[ 'search'];
        //$this->load->model('Login_model');
        //$result['diss']=$this->Mymodel->selectorganizer($search);
$username=$this->session->userdata('username');


          //  $data['diss']=$result;
						$re=array('dis'=>$this->Mymodel->disuser($username),'diss'=>$this->Mymodel->selectorganizer($search),'diss'=>$this->Mymodel->selectorganizercategory($search));
             $this->load->view('user_searchresult',$re);

    }
}
function usersearch()
{

	$result['dis']=$this->Mymodel->districtdetailes();
	$this->load->view('login',$result);
	
}
function searchaddtocart()
{

	$rating=$this->input->post('rating');
	$booking_date=$this->input->post('date');
	//$numberofpackets=$this->input->post('number_ofpackets');
	$itemid=$this->input->post('itemid');
	$username=$this->session->userdata('username');
	$customerid=$this->session->userdata('id');
	$booking_status=0;
	$result=$this->Mymodel->checkorder($itemid);
	if(!$result)
	{
	$bookingdata=array('cust_id'=>$customerid,'product_id'=>$itemid,'date_ofbooking'=>$booking_date,'number_ofpacket'=>'1','rating'=>$rating,'d_address'=>' ','ordernumber'=>' ','booking_status'=>$booking_status);
	$resultarray=array('cart'=>$this->Mymodel->addtocart($bookingdata),'diss'=>$this->Mymodel->displaycart($customerid),'dis'=>$this->Mymodel->disuser($username));
	$this->load->view('checkout',$resultarray);
	}
	else
	{
		$bookingdata=array('cust_id'=>$customerid,'product_id'=>$itemid,'date_ofbooking'=>$booking_date,'rating'=>$rating,'booking_status'=>$booking_status);
	$resultarray=array('diss'=>$this->Mymodel->displaycart($customerid),'dis'=>$this->Mymodel->disuser($username));
	$this->session->set_flashdata('response',"Item  already exist in cart...!!");
	$this->load->view('checkout',$resultarray);
	}



}

}
?>
