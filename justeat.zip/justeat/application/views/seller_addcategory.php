<?php 
$CI=& get_instance();
$a=$CI->sessionin();
if($a)
{
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Justeats Seller Profile </title>
		
        <?php include 'adminstyle.php' ?> 
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      
    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
             <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo site_url('controller/seller_home');?>">Seller</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> Seller</a></li>
                </ul>
				
                <ul class="nav navbar-right navbar-top-links">
                    
                    <li class="dropdown">
                    	
                         <a class="dropdown-toggle"  href="<?php echo site_url('controller/logout');?>">
                            <i class="fa fa-user fa-fw"></i> logout <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                           
                            <?php /*?><li><a href="<?php echo site_url('controller/logout');?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a><?php */?>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-right navbar-top-links">
                <?php 
								foreach($diss as $row)
								{
									$name=$row->name;
								?>	
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> hi,<?php echo $name;?></a></li>
                    <?php
                    }
                    ?>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                </span>
                                </div>
                                <!-- /input-group -->
                            </li>
                           
                          <?php include 'seller_nav.php' ?>
                    </div>
                </div>
            </nav>

           
           
           
           
            <div id="page-wrapper">
           
           
           <hr>
           
                <div class="container bootstrap snippet col-lg-10">
                    <div class="row">
                        <div class="col-sm-10"><h1>Add New Category</h1></div>
                        <div class="col-sm-2"><a href="" class="pull-right"></a></div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3"><!--left col-->
                              
         
                          
                        </div><!--/col-3-->
                        <div class="col-sm-9">
                            
                
                              
                          <div class="tab-content">
                            <div class="tab-pane active" id="home">
                                <hr>
                                  <form class="form" action="<?php echo site_url('controller/addcategory');?>" method="post" id="registrationForm">
                                      <div class="form-group">
                                          <font color="#0000FF" size="+3" face="Courier New, Courier, monospace">
                                          <div class="col-xs-6">
                                              <label for="first_name"><h4>New category Name</h4></label>
                                              <input type="text" class="form-control" name="newcatogory" id="newcatogory" placeholder="category Name" required>
                                          </div>
                                      </div>
                           </font>
                                      <font color="#0000FF" size="+3" face="Courier New, Courier, monospace">
                                      <div class="form-group">
                                           <div class="col-xs-12">
                                                <br>
                                                <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                                <button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button><br><br>
                                                <font color="#FF3333" size="+1" face="Courier New, Courier, monospace">
                                                <?php 
												//$a=$this->session->userdata('categorymsg');
												
													//echo '<font color="#0000FF" size="+3" face="Courier New, Courier, monospace">''</font>';
													echo $this->session->flashdata('responsx');
												?></font>
                                            </div>
                                      </div>
                                </form>
                              <form class="form" action="<?php echo site_url('controller/addsubcategory');?>" method="post" id="registrationForm">
                                     
                                     
                               <div class="form-group">
                                         
                                          <div class="col-xs-6">
                                            <label for="last_name"><h4>Category</h4></label>
                                            
                                            <select name="category" id="category" class="form-control">
                                             <?php 
										  foreach($dis as $row)
										  {
											  $categoryname=$row->category_name;
											  $categoryid=$row->category_id;
										  ?>
                                          	
                                            <option value="<?php echo $categoryid;?>"><?php echo $categoryname;?></option>
                                            <?php
										  }
										  ?>
                                            </select>
                                    
                                          </div>
                                         
                                      </div>
                                      <div class="form-group">
                                          
                                          <div class="col-xs-6">
                                              <label for="first_name"><h4>New sub category Name</h4></label>
                                              <input type="text" class="form-control" name="newcatogory" id="newcatogory" placeholder="category Name" required>
                                          </div>
                                      </div>
                                      
                           
                                      <font color="#0000FF" size="+3" face="Courier New, Courier, monospace">
                                      <div class="form-group">
                                           <div class="col-xs-12">
                                                <br>
                                                <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                                <button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button><br><br>
                                               
                                            </div>
                                      </div>
                                </form> 	
                              <hr>
                              
                             </div><!--/tab-pane-->
                             
                          </div><!--/tab-content-->
                
                        </div><!--/col-9-->
                    </div><!--/row-->
                           
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="<?php echo base_url('js/jquery.min.js');?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo base_url('js/metisMenu.min.js');?>"></script>

        <!-- DataTables JavaScript -->
        <script src="<?php echo base_url('js/dataTables/jquery.dataTables.min.js');?>"></script>
        <script src="<?php echo base_url('js/dataTables/dataTables.bootstrap.min.js');?>"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo base_url('js/startmin.js');?>"></script>
    </body>
</html>
<?php
}
else
{
	$CI->index();
	
}
?>