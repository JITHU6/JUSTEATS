
<?php include 'adminstyle.php' ?> 
 							  
<li>
                                <a href="<?php echo site_url('controller/seller_home');?>" class="active"><i class="fa fa-dashboard fa-fw"></i> Home</a>
</li>
                           
                            <li>
                                <a href="<?php echo site_url('controller/seller_profile');?>"><i class="fa fa-table fa-fw"></i> Profile</a>
                            </li>
                             <li>
                                <a href="<?php echo site_url('controller/seller_additem');?>"><i class="fa fa-table fa-fw"></i> Add Item</a>
                       
                            </li>
                            <li>
                                <a href="<?php echo site_url('controller/seller_viewaddeditem');?>"><i class="fa fa-table fa-fw"></i>View/Edit</a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('controller/seller_addcategory');?>"><i class="fa fa-table fa-fw"></i> Suggest Category</a>
                            </li>
                            
                             <li>
                                <a href="<?php echo site_url('controller/');?>"><i class="fa fa-table fa-fw"></i> Report</a>
                            </li>
                            
                            
                            <?php /*?><li>
                                <a href="forms.html"><i class="fa fa-edit fa-fw"></i> Forms</a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-wrench fa-fw"></i> UI Elements<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="panels-wells.html">Panels and Wells</a>
                                    </li>
                                    <li>
                                        <a href="buttons.html">Buttons</a>
                                    </li>
                                    <li>
                                        <a href="notifications.html">Notifications</a>
                                    </li>
                                    <li>
                                        <a href="typography.html">Typography</a>
                                    </li>
                                    <li>
                                        <a href="icons.html"> Icons</a>
                                    </li>
                                    <li>
                                        <a href="grid.html">Grid</a>
                                    </li>
                                </ul>
                                 /.nav-second-level 
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-sitemap fa-fw"></i> Multi-Level Dropdown<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="#">Second Level Item</a>
                                    </li>
                                    <li>
                                        <a href="#">Second Level Item</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level <span class="fa arrow"></span></a>
                                        <ul class="nav nav-third-level">
                                            <li>
                                                <a href="#">Third Level Item</a>
                                            </li>
                                            <li>
                                                <a href="#">Third Level Item</a>
                                            </li>
                                            <li>
                                                <a href="#">Third Level Item</a>
                                            </li>
                                            <li>
                                                <a href="#">Third Level Item</a>
                                            </li>
                                        </ul>
                                         /.nav-third-level 
                                    </li>
                                </ul>
                                 /.nav-second-level 
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-files-o fa-fw"></i> Sample Pages<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="blank.html">Blank Page</a>
                                    </li>
                                    <li>
                                        <a href="login.html">Login Page</a>
                                    </li>
                                </ul>
                                 /.nav-second-level 
                            </li><?php */?>
			
