

<!DOCTYPE html>
<html>

 <head>
<title>Justeats</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />


<link href="<?php echo base_url('css/bootstrap.css');?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url('css/style.css');?>" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>

<!-- font-awesome icons -->
<link href="<?php echo base_url('css/font-awesome.css');?>" rel="stylesheet" type="text/css" media="all" />
<!-- //font-awesome icons -->
<!-- js -->
<script src="<?php echo base_url('js/jquery-1.11.1.min.js');?>"></script>
<script src='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic'></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo base_url('js/move-top.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/easing.js');?>"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->


<!-- start-smoth-scrolling -->
<script>
	var pancard=/^[A-Z]{5}[0-9]{4}[A-Z]{1}/;
var ck_name = /^[A-Za-z0-9 ]{3,20}$/;
	var pat1=/^[0-9](6,6)+$/;
	var addr=/^[a-zA-Z0-9\s,.'-]{3,}$/;
	var pat3=/^[0-9]{6}/;
function validationForm(signup){


	if (document.registration.type.value=="")
	{
        alert ("Please select a type.");
        return false;
    }
	if (document.registration.Name.value=="")
	{
        alert ("Please fill in your Name.");
        return false;
    }
	else if (!ck_name.test(document.registration.Name.value))
	{
        alert ("Please fill in your Correct Name.");
        return false;
    }

if (document.registration.Phone.value=="")
	{
        alert ("Please fill in your phone.");
        return false;
    }
	else if(isNaN(document.registration.Phone.value))
	{
		alert("Please check your mobile number");
		return false;
	}
	else if(document.registration.Phone.value.length!=10)
	{
		alert("Enter 10 digit number");
		return false;
	}

else if (document.registration.Address1.value=="")
    {
        alert ("Please fill in your Address line 1.");
		document.registration.Address1.value.focus();
        return false;
    }
else if (!addr.test(document.registration.Address1.value))
    {
        alert ("Please fill in your correct Address line 1.");
		document.registration.Address1.value.focus();
        return false;
    }

    if (document.registration.Address2.value=="")
    {
        alert ("Please fill in your Address line 2.");
		document.registration.Address2.value.focus();
        return false;
    }
	else if (!addr.test(document.registration.Address2.value))
    {
        alert ("Please fill in your correct Address line 2.");
		document.registration.Address2.value.focus();
        return false;
    }

	if (document.registration.City.value=="")
    {
        alert ("Please fill in your City.");
		document.registration.City.value.focus();
        return false;
    }
	if (!addr.test(document.registration.City.value))
    {
        alert ("Please fill in your correct City.");
		document.registration.City.value.focus();
        return false;
    }
	if (document.registration.District.value=="")
    {
        alert ("Please select your District.");
		document.registration.District.value.focus();
        return false;
    }
	if (document.registration.Pincode.value=="")
    {
        alert ("Please fill in your Pin code.");
		document.registration.Pincode.value.focus();
        return false;
    }
	else if (!pat3.test(document.registration.Pincode.value))  {
            alert("Pin code should be 6 digits ");
            Pincode.focus();
            return false;
        }
		else if (isNaN(document.registration.Pincode.value))
    {
        alert ("Please fill in your correct pincode.");
        return false;
    }

		if (!pancard.test(document.registration.Pancard.value))
		 {
            alert("Pancard should be 5 letters 4 digits and 1 letter ");
            Pancard.focus();
            return false;
        }




    if (document.registration.Password.value=="")
    {
        alert ("Please fill in your password.");
        return false;
    }

    else if (document.registration.Password.length  < 5)
            {
                alert ("short password.");
                Password.focus();
                return false;
            }
	if (document.registration.CdelivererPassword.value=="")
    {
        alert ("Please fill in your confirm password.");
        return false;
    }
	if (document.registration.Password.value!=document.registration.CPassword.value)
    {
        alert (" password mismatch.");
        return false;
	}

}
function validationFormLogin(login){
	if (document.login.Username.value=="")
	{
        alert ("Please fill in your Email Id.");
        return false;
    }
	if (document.login.Password.value=="")
	{
        alert ("Please fill in your Password.");
        return false;
    }
}
</script>
	</head>
<body>

<!-- header -->
<div class="agileits_header">
  <div class="w3l_offers">
    <a href="<?php echo site_url('controller/index')?>">Taste of Kerala!</a>
  </div>
  <div class="w3l_search">
    <form action="<?php echo site_url('controller/userselect')?>" method="get">
      <input type="text" name="search" value="Search a product..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search a product...';}" required>
      <input type="submit" value="">
    </form>
  </div>



  <div class="w3l_header_right">
<ul >
  <li class="dropdown profile_details_drop w3l_header_left">
    <a href="<?php echo site_url('controller/login')?>" class="button" data-toggle="dropdown"><i  aria-hidden="true"><label style="font-family:Verdana, Geneva, sans-serif;border-color:#FFF;">Login/Sign Up</label></i></a>

  </li>
</ul>
</div>


<div class="w3l_header_right1">
    <h2><a href="<?php echo site_url('controller/ucontact')?>">Contact Us</a></h2>
  </div>
  <div class="clearfix"> </div>
</div>
<!-- script-for sticky-nav -->
<script>
$(document).ready(function() {
   var navoffeset=$(".agileits_header").offset().top;
   $(window).scroll(function(){
    var scrollpos=$(window).scrollTop();
    if(scrollpos >=navoffeset){
      $(".agileits_header").addClass("fixed");
    }else{
      $(".agileits_header").removeClass("fixed");
    }
   });

});
</script>
<!-- //script-for sticky-nav -->
<div class="logo_products">
  <div class="container">
    <div class="w3ls_logo_products_left">
      <!--<h1><a href="index#"><span>Grocery</span> Store</a></h1>-->
              <img src="<?php echo base_url('images/logo.png');?>">
    </div>
    <div class="w3ls_logo_products_left1">
      <ul class="special_items">
        <!--<li><a href="events#">Events</a><i>/</i></li>-->
        <li><a href="<?php echo site_url('controller/uabout')?>">About Us</a><i>/</i></li>
        <li><a href="#">Best Deals</a><i>/</i></li>


        <!--<li><a href="services#">Services</a></li>-->
      </ul>
    </div>
    <div class="w3ls_logo_products_left1">
      <ul class="phone_email">
        <li><i class="fa fa-phone" aria-hidden="true"></i>+919497609019</li>
        <li><i class="fa fa-envelope-o" aria-hidden="true"></i><a href="mailto:store@justeats.com">store@justeats.com</a></li>&nbsp;&nbsp;&nbsp;&nbsp;

      </ul>

    </div>
    <div class="clearfix"> </div>
  </div>
</div>
<!-- //header -->
<!-- products-breadcrumb -->
	<div class="products-breadcrumb">
		<div class="container">
			<ul>
				<li><i class="fa fa-home" aria-hidden="true"></i><a href="<?php echo site_url('controller/index')?>">Home</a><span>|</span></li>
				<li>Sign In & Sign Up</li>
			</ul>
		</div>
	</div>
<!-- //products-breadcrumb -->
<!-- banner -->
	 <div class="banner">
		<div class="w3l_banner_nav_left">
      <nav class="navbar nav_bottom">
  			 <!-- Brand and toggle get grouped for better mobile display -->
  			  <div class="navbar-header nav_2">
  				  <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
  					<span class="sr-only">Toggle navigation</span>
  					<span class="icon-bar"></span>
  					<span class="icon-bar"></span>
  					<span class="icon-bar"></span>
  				  </button>
  			   </div>
  <!-- Collect the nav links, forms, and other content for toggling -->
  				<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
  					<ul class="nav navbar-nav nav_1">


  						<li class="dropdown mega-dropdown active">
  							<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown" >Cookies & Crackers<span class="caret"></span></a>
  							<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
  								<div class="w3ls_vegetables">
  									<ul>
  										<li><a href="<?php echo site_url('controller/snacks')?>" >Biscuits </a></li>
  										<li><a href="<?php echo site_url('controller/Cookies')?>">Cookies </a></li>
  										<li><a href="<?php echo site_url('controller/Straws ')?>">Straws </a></li>
  									</ul>
  								</div>
  							</div>
  						</li>

  						<li class="dropdown mega-dropdown active">
  							<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Antipasti<span class="caret"></span></a>
  							<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
  								<div class="w3ls_vegetables">
  									<ul>
  										<li><a href="<?php echo site_url('controller/Olives ')?>"> Olives, Capers & Tapenades
  </a></li>

  										<li><a href="<?php echo site_url('controller/Gherkins ')?>">Gherkins & Jalapenos </a></li>
                          <li><a href="<?php echo site_url('controller/Sundried ')?>">Sundried Tomatoes & Others
  </a></li>
  									</ul>
  								</div>
  							</div>
  						</li>




  <li class="dropdown mega-dropdown active">
  	<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Dry Snacks<span class="caret"></span></a>
  	<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
  		<div class="w3ls_vegetables">
  			<ul>
  				<li><a href="<?php echo site_url('controller/Chips ')?>"> Chips , Nachos & Crisps</a></li>

  				<li><a href="<?php echo site_url('controller/Dryfruits ')?>">Dry Fruits & Nuts </a></li>
  						<li><a href="<?php echo site_url('controller/Dryseeds ')?>">Dry Seeds</a></li>
  						<li><a href="<?php echo site_url('controller/DrySnacks ')?>">Indian & Dry Snacks </a></li>

  			</ul>
  		</div>
  	</div>
  </li>


  <li class="dropdown mega-dropdown active">
  	<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Chocolates<span class="caret"></span></a>
  	<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
  		<div class="w3ls_vegetables">
  			<ul>
  				<li><a href="<?php echo site_url('controller/Funsize ')?>"> Funsize Packs & Snacksize Bars</a></li>

  				<li><a href="<?php echo site_url('controller/Milk ')?>">Milk, Dark & Mint Chocolates </a></li>
  						<li><a href="<?php echo site_url('controller/Fudge ')?>">Fudge & Truffles</a></li>
  						<li><a href="<?php echo site_url('controller/Bouquettes ')?>">Gift Packs & Bouquettes </a></li>

  			</ul>
  		</div>
  	</div>
  </li>

  					</ul>
  				 </div>
                  </nav>
		</div>
               <!-- /.navbar-collapse -->

               <!-- /.navbar-collapse -->


		<div class="w3l_banner_nav_right">
<!-- login -->
		<div class="w3_login">
			<h3>Sign In & Sign Up</h3>
			<div class="w3_login_module">
				<div class="module form-module">
				  <div class="toggle"><i class="fa fa-times fa-pencil"></i>
					<div class="tooltip">Sign Up</div>
				  </div>
				  <div class="form">
					<h2>Login to your account</h2>
					<form name="login" id="login" action="<?php echo site_url('controller/ulogin');?>" method="post">
					  <input type="text" name="username" placeholder="Username" required>
					  <input type="password" name="password" placeholder="Password" required>
					  <input type="submit" value="Login" onClick="validationFormLogin(login)">
                      <font color="#FF0000" size="+1" face="Courier New, Courier, monospace">
					<?php
				  echo $this->session->flashdata('responsec');
				  ?>
                  <?php
				  echo $this->session->flashdata('responsed');
				  ?></font>
                    </form>

				  </div>
				  <div class="form">
					<h2>Create an account</h2>

					<form id="registration" name="registration" action="<?php echo site_url('controller/insertuser');?>"  method="post">
					  <label></label>
                      <select name="type" id="type" style="width:100%;margin-bottom:5%;padding:2%" >
 						 <option value="">Select Type</option>
                         <option value="Shopper" >Shopper</option>
  						  <option value="Seller">Seller</option>

						  </select>
                      <input type="text" name="name" id="Name" placeholder="Full Name" required>
                      <input type="text" name="phone" id="Phone" placeholder="Phone Number"  required>
                      <input type="email" name="email" id="Email" placeholder="Email Address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
                      <input type="text" name="address1" id="Address1" placeholder="Address 1" required>
                      <input type="text" name="address2" id="Address2" placeholder="Address 2" required>
                      <input type="text" name="city" id="City" placeholder="City" required>
                      <label></label>
                      <select name="district" id="District" style="width:100%;margin-bottom:5%;padding:2%">
 						 <option value="" selected>Select District</option>
                         <?php
						 foreach($dis as $row)
						 {
							 $districtname=$row->district_name;
							 $districtid=$row->district_id;

						?>
                         <option value="<?php echo $districtid;?>" ><?php echo $districtname;?></option>
  						  <?php
						 }
						 ?>

						  </select>
                       <input type="text" name="pincode" id="Pincode" placeholder="Pincode" required>
                     <!-- <input type="text" name="pancard" id="Pancard" placeholder="Pancard"  title="pancard number must be 5 uppercase letters 4 digits and 1 uppercase letter" required>-->
					  <input type="password" name="password" id="Password" placeholder="Password" title="password must contain 1 uppercase 1 lowercase and 1 number" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).*$" required>
                      <input type="password" name="cpassword" id="CPassword" placeholder="Confirm Password" pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).*$" minlength="5" required>
					  <input type="submit" value="Register" onclick="validationForm()">
					</form>


				  </div>
                 <font color="#FF0000" size="+1" face="Courier New, Courier, monospace">
                  <?php
				  echo $this->session->flashdata('responsa');
				  ?>
                  </font>
				  <div class="cta"><a href="<?php echo site_url('controller/forgotpwd')?>">Forgot your password?</a></div>

				</div>
			</div>
			<script>
				$('.toggle').click(function(){
				  // Switches the Icon
				  $(this).children('i').toggleClass('fa-pencil');
				  // Switches the forms
				  $('.form').animate({
					height: "toggle",
					'padding-top': 'toggle',
					'padding-bottom': 'toggle',
					opacity: "toggle"
				  }, "slow");
				});
			</script>
		</div>
<!-- //login -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->


<!-- footer -->
	<div class="footer">
		<div class="container">
			<!-- <div class="col-md-3 w3_footer_grid">
				<h3>information</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="events#">Events</a></li>
					<li><a href="about#">About Us</a></li>
					<li><a href="products#">Best Deals</a></li>
					<li><a href="services#">Services</a></li>
					<li><a href="short-codes#">Short Codes</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3_footer_grid">
				<h3>policy info</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="faqs#">FAQ</a></li>
					<li><a href="privacy#">privacy policy</a></li>
					<li><a href="privacy#">terms of use</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3_footer_grid">
				<h3>what in stores</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="pet#">Pet Food</a></li>
					<li><a href="frozen#">Frozen Snacks</a></li>
					<li><a href="kitchen#">Kitchen</a></li>
					<li><a href="products#">Branded Foods</a></li>
					<li><a href="household#">Households</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3_footer_grid">
				<h3>twitter posts</h3>
				<ul class="w3_footer_grid_list1">
					<li><label class="fa fa-twitter" aria-hidden="true"></label><i>01 day ago</i><span>Non numquam <a href="#">http://sd.ds/13jklf#</a>
						eius modi tempora incidunt ut labore et
						<a href="#">http://sd.ds/1389kjklf#</a>quo nulla.</span></li>
					<li><label class="fa fa-twitter" aria-hidden="true"></label><i>02 day ago</i><span>Con numquam <a href="#">http://fd.uf/56hfg#</a>
						eius modi tempora incidunt ut labore et
						<a href="#">http://fd.uf/56hfg#</a>quo nulla.</span></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
			<div class="agile_footer_grids">
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						<h4>100% secure payments</h4>
						<img src="images/card.png" alt=" " class="img-responsive" />
					</div>
				</div>
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						<h5>connect with us</h5>
						<ul class="agileits_social_icons">
							<li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#" class="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#" class="dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>-->
			<div class="wthree_footer_copy">
				<p>© 2018 Justeats. All rights reserved | Design by <a href="<?php echo site_url('controller/index')?>">Justeats</a></p>
			</div>
		</div>
	</div>
<!-- //footer -->
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
    $(".dropdown").hover(
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');
        }
    );
});
</script>
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

			});
	</script>
<!-- //here ends scrolling icon -->
<script src="js/minicart.js"></script>
<script>
		paypal.minicart.render();

		paypal.minicart.cart.on('checkout', function (evt) {
			var items = this.items(),
				len = items.length,
				total = 0,
				i;

			// Count the number of each item in the cart
			for (i = 0; i < len; i++) {
				total += items[i].get('quantity');
			}

			if (total < 3) {
				alert('The minimum order quantity is 3. Please add more to your shopping cart before checking out');
				evt.preventDefault();
			}
		});

	</script>
</body>
</html>
