<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Justeats</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />


<link href="<?php echo base_url('css/bootstrap.css');?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url('css/style.css');?>" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>

<!-- font-awesome icons -->
<link href="<?php echo base_url('css/font-awesome.css');?>" rel="stylesheet" type="text/css" media="all" />
<!-- //font-awesome icons -->
<!-- js -->
<script src="<?php echo base_url('js/jquery-1.11.1.min.js');?>"></script>
<script src='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic'></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo base_url('js/move-top.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/easing.js');?>"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
</head>

<body>
<!-- header -->
<div class="agileits_header">
	<div class="w3l_offers">
		<a href="<?php echo site_url('controller/index')?>">Taste of Kerala!</a>
	</div>
	<div class="w3l_search">
		<form action="<?php echo site_url('controller/userselect')?>" method="get">
			<input type="text" name="search" value="Search a product..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search a product...';}" required>
			<input type="submit" value="">
		</form>
	</div>



	<div class="w3l_header_right">
<ul >
	<li class="dropdown profile_details_drop w3l_header_left">
		<a href="<?php echo site_url('controller/login')?>" class="button" data-toggle="dropdown"><i  aria-hidden="true"><label style="font-family:Verdana, Geneva, sans-serif;border-color:#FFF;">Login/Sign Up</label></i></a>

	</li>
</ul>
</div>


<div class="w3l_header_right1">
		<h2><a href="<?php echo site_url('controller/ucontact')?>">Contact Us</a></h2>
	</div>
	<div class="clearfix"> </div>
</div>
<!-- script-for sticky-nav -->
<script>
$(document).ready(function() {
	 var navoffeset=$(".agileits_header").offset().top;
	 $(window).scroll(function(){
		var scrollpos=$(window).scrollTop();
		if(scrollpos >=navoffeset){
			$(".agileits_header").addClass("fixed");
		}else{
			$(".agileits_header").removeClass("fixed");
		}
	 });

});
</script>
<!-- //script-for sticky-nav -->
<div class="logo_products">
	<div class="container">
		<div class="w3ls_logo_products_left">
			<!--<h1><a href="index.html"><span>Grocery</span> Store</a></h1>-->
							<img src="<?php echo base_url('images/logo.png');?>">
		</div>
		<div class="w3ls_logo_products_left1">
			<ul class="special_items">
				<!--<li><a href="events.html">Events</a><i>/</i></li>-->
				<li><a href="<?php echo site_url('controller/uabout')?>">About Us</a><i>/</i></li>
				<li><a href="#">Best Deals</a><i>/</i></li>


				<!--<li><a href="services.html">Services</a></li>-->
			</ul>
		</div>
		<div class="w3ls_logo_products_left1">
			<ul class="phone_email">
				<li><i class="fa fa-phone" aria-hidden="true"></i>+919497609019</li>
				<li><i class="fa fa-envelope-o" aria-hidden="true"></i><a href="mailto:store@justeats.com">store@justeats.com</a></li>&nbsp;&nbsp;&nbsp;&nbsp;

			</ul>

		</div>
		<div class="clearfix"> </div>
	</div>
</div>
<!-- //header -->
<!-- products-breadcrumb -->
	<div class="products-breadcrumb">
		<div class="container">
			<ul>
				<li><i class="fa fa-home" aria-hidden="true"></i><a href="<?php echo site_url('controller/index')?>">Home</a><span>|</span></li>
				<li>About Us</li>
			</ul>
		</div>
	</div>
<!-- //products-breadcrumb -->
<!-- banner -->
	<div class="banner">
		<div class="w3l_banner_nav_left">
			<nav class="navbar nav_bottom">
				 <!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						</button>
					 </div>
	<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav nav_1">


							<li class="dropdown mega-dropdown active">
								<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown" >Cookies & Crackers<span class="caret"></span></a>
								<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
									<div class="w3ls_vegetables">
										<ul>
											<li><a href="<?php echo site_url('controller/snacks')?>" >Biscuits </a></li>
											<li><a href="<?php echo site_url('controller/Cookies')?>">Cookies </a></li>
											<li><a href="<?php echo site_url('controller/Straws ')?>">Straws </a></li>
										</ul>
									</div>
								</div>
							</li>

							<li class="dropdown mega-dropdown active">
								<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Antipasti<span class="caret"></span></a>
								<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
									<div class="w3ls_vegetables">
										<ul>
											<li><a href="<?php echo site_url('controller/Olives ')?>"> Olives, Capers & Tapenades
	</a></li>

											<li><a href="<?php echo site_url('controller/Gherkins ')?>">Gherkins & Jalapenos </a></li>
													<li><a href="<?php echo site_url('controller/Sundried ')?>">Sundried Tomatoes & Others
	</a></li>
										</ul>
									</div>
								</div>
							</li>




	<li class="dropdown mega-dropdown active">
		<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Dry Snacks<span class="caret"></span></a>
		<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
			<div class="w3ls_vegetables">
				<ul>
					<li><a href="<?php echo site_url('controller/Chips ')?>"> Chips , Nachos & Crisps</a></li>

					<li><a href="<?php echo site_url('controller/Dryfruits ')?>">Dry Fruits & Nuts </a></li>
							<li><a href="<?php echo site_url('controller/Dryseeds ')?>">Dry Seeds</a></li>
							<li><a href="<?php echo site_url('controller/DrySnacks ')?>">Indian & Dry Snacks </a></li>

				</ul>
			</div>
		</div>
	</li>


	<li class="dropdown mega-dropdown active">
		<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Chocolates<span class="caret"></span></a>
		<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
			<div class="w3ls_vegetables">
				<ul>
					<li><a href="<?php echo site_url('controller/Funsize ')?>"> Funsize Packs & Snacksize Bars</a></li>

					<li><a href="<?php echo site_url('controller/Milk ')?>">Milk, Dark & Mint Chocolates </a></li>
							<li><a href="<?php echo site_url('controller/Fudge ')?>">Fudge & Truffles</a></li>
							<li><a href="<?php echo site_url('controller/Bouquettes ')?>">Gift Packs & Bouquettes </a></li>

				</ul>
			</div>
		</div>
	</li>

						</ul>
					 </div>
									</nav>
		</div>
		<div class="w3l_banner_nav_right">
<!-- about -->
		<div class="privacy about">
			<h3>About Us</h3>
			<p class="animi">We are a team providing online delivery of bakery products all over the kerala.We provide an easy way to sellers for selling their product and reaching it to a mass users.The customers can get veriety of pructs from various sellers depending on their demand.We have many teams of highly active
			<div class="agile_about_grids">
				<div class="col-md-6 agile_about_grid_right">
					<img src="<?php echo base_url('images/b.jpg');?>" alt=" " class="img-responsive" />
				</div>
				<div class="col-md-6 agile_about_grid_left">
					<ol>
						<li>sellers</li>
						<li>Quality Checking Team</li>
						<li>Delivery Team</li>
						<?php /*?><li></li>
						<li>excepturi sint occaecati cupiditate</li>
						<li>accusamus et iusto odio</li><?php */?>
					</ol>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
<!-- //about -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->
<!-- team -->
	<div class="team">
		<div class="container">
			<h3>Meet Our Amazing Team</h3>
			<div class="agileits_team_grids">
				<div class="col-md-3 agileits_team_grid">
					<img src="<?php echo base_url('images/jithu.jpg');?>" alt=" " class="img-responsive" />
					<h4>Jithu Benny</h4>
					<p>Manager</p>
					<ul class="agileits_social_icons agileits_social_icons_team">
						<li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-md-3 agileits_team_grid">
					<img src="<?php echo base_url('images/jithu.jpg');?>" alt=" " class="img-responsive" />
					<h4>Michael Rick</h4>
					<p>Supervisor</p>
					<ul class="agileits_social_icons agileits_social_icons_team">
						<li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-md-3 agileits_team_grid">
					<img src="<?php echo base_url('images/jithu.jpg');?>" alt=" " class="img-responsive" />
					<h4>Thomas Carl</h4>
					<p>Supervisor</p>
					<ul class="agileits_social_icons agileits_social_icons_team">
						<li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-md-3 agileits_team_grid">
					<img src="<?php echo base_url('images/jithu.jpg');?>" alt=" " class="img-responsive" />
					<h4>Laura Lee</h4>
					<p>CEO</p>
					<ul class="agileits_social_icons agileits_social_icons_team">
						<li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //team -->
<!-- testimonials -->
	<?php /*?><div class="testimonials">
		<div class="container">
			<h3>Testimonials</h3>
				<div class="w3_testimonials_grids">
					<div class="wmuSlider example1 animated wow slideInUp" data-wow-delay=".5s">
						<div class="wmuSliderWrapper">
							<article style="position: absolute; width: 100%; opacity: 0;">
								<div class="banner-wrap">
									<div class="col-md-6 w3_testimonials_grid">
										<p><i class="fa fa-quote-right" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
											voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
											repellat.</p>
										<h4>Andrew Smith <span>Customer</span></h4>
									</div>
									<div class="col-md-6 w3_testimonials_grid">
										<p><i class="fa fa-quote-right" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
											voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
											repellat.</p>
										<h4>Thomson Richard <span>Customer</span></h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</article>
							<article style="position: absolute; width: 100%; opacity: 0;">
								<div class="banner-wrap">
									<div class="col-md-6 w3_testimonials_grid">
										<p><i class="fa fa-quote-right" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
											voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
											repellat.</p>
										<h4>Crisp Kale <span>Customer</span></h4>
									</div>
									<div class="col-md-6 w3_testimonials_grid">
										<p><i class="fa fa-quote-right" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
											voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
											repellat.</p>
										<h4>John Paul <span>Customer</span></h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</article>
							<article style="position: absolute; width: 100%; opacity: 0;">
								<div class="banner-wrap">
									<div class="col-md-6 w3_testimonials_grid">
										<p><i class="fa fa-quote-right" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
											voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
											repellat.</p>
										<h4>Rosy Carl <span>Customer</span></h4>
									</div>
									<div class="col-md-6 w3_testimonials_grid">
										<p><i class="fa fa-quote-right" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
											voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
											repellat.</p>
										<h4>Rockson Doe <span>Customer</span></h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</article>
						</div>
					</div>
					<script src="js/jquery.wmuSlider.js"></script>
					<script>
						$('.example1').wmuSlider();
					</script>
				</div>
		</div>
	</div><?php */?>
<!-- //testimonials -->
<!-- newsletter -->
	<div class="newsletter">
		<div class="container">
			<div class="w3agile_newsletter_left">
				<h3>sign up for our newsletter</h3>
			</div>
			<div class="w3agile_newsletter_right">
				<form action="#" method="post">
					<input type="email" name="Email" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" required>
					<input type="submit" value="subscribe now">
				</form>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //newsletter -->
<!-- footer -->
	<div class="footer">
		<div class="container">

			<div class="clearfix"> </div>
			<div class="agile_footer_grids">
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						<h4>100% secure payments</h4>
						<img src="images/card.png" alt=" " class="img-responsive" />
					</div>
				</div>
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						<h5>connect with us</h5>
						<ul class="agileits_social_icons">
							<li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#" class="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#" class="dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="wthree_footer_copy">
				<p>© 2018 Justeats. All rights reserved | Design by <a href="<?php echo site_url('controller/index')?>">Justeats</a></p>
			</div>
		</div>
	</div>
<!-- //footer -->
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
    $(".dropdown").hover(
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');
        }
    );
});
</script>
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

			});
	</script>
<!-- //here ends scrolling icon -->
<script src="js/minicart.js"></script>
<script>
		paypal.minicart.render();

		paypal.minicart.cart.on('checkout', function (evt) {
			var items = this.items(),
				len = items.length,
				total = 0,
				i;

			// Count the number of each item in the cart
			for (i = 0; i < len; i++) {
				total += items[i].get('quantity');
			}

			if (total < 3) {
				alert('The minimum order quantity is 3. Please add more to your shopping cart before checking out');
				evt.preventDefault();
			}
		});

	</script>
</body>
</html>
