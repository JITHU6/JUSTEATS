<?php
$CI=& get_instance();
$a=$CI->sessionin();
if($a)
{
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Justeats Seller Profile </title>

        <?php include 'adminstyle.php' ?>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo site_url('controller/seller_home');?>">Seller</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> Seller</a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">

                    <li class="dropdown">

                         <a class="dropdown-toggle"  href="<?php echo site_url('controller/logout');?>">
                            <i class="fa fa-user fa-fw"></i> logout <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">

                            <?php /*?><li><a href="<?php echo site_url('controller/logout');?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a><?php */?>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-right navbar-top-links">
                <?php
								foreach($dis as $row)
								{
									$name=$row->name;
								?>
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> hi,<?php echo $name;?></a></li>
                    <?php
                    }
                    ?>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                </span>
                                </div>
                                <!-- /input-group -->
                            </li>

                          <?php include 'seller_nav.php' ?>
                    </div>
                </div>
            </nav>





            <div id="page-wrapper">


           <hr>

                <div class="container bootstrap snippet col-lg-10">
                    <div class="row">
                        <div class="col-sm-10"><h1>Seller Profile</h1></div>
                        <?php /*?><div class="col-sm-2"><a href="/users" class="pull-right"><img title="profile image" class="img-circle img-responsive" src""></a></div><?php */?>
                    </div>

						     <div class="row">
                        <div class="col-sm-3"><!--left col-->

                    <form class="form" action="<?php echo site_url('controller/sellerinfo');?>" method="post" id="registrationForm" enctype="multipart/form-data">
                    <?php

								foreach($dis as $row)
								{
									$email=$row->email;
									$name=$row->name;
									$address1=$row->address1;
									$address2=$row->address2;
									$city=$row->city;
									$districtida=$row->district_id;
									$districtnamea=$row->district_name;
									$phone=$row->rphone;

									$pincode=$row->pincode;
									$pancard=$row->pancard;
									$experience=$row->experience;
									$image=$row->image;
									$licence=$row->licence_number;
									
									if($licence==0)
									{
										echo "<script> alert('Update your licence number')</script>";
									}
									if($pancard=="")
									{
										echo "<script> alert('Update your pancard number')</script>";
									}
								?>



                      <div class="text-center">
                      
                        <img src="../../images/profile/<?php echo $image; ?>" class="avatar img-circle img-thumbnail" alt="<?php echo $image; ?>">
                       
                        <h6>Upload a different photo...</h6>
                        <input type="file" name ="sellerprofile" class="text-center center-block file-upload"  value=""  accept=".png, .jpg, .jpeg,.JPG" >
                       

                      </div></hr><br>






                          <div class="panel panel-default">

                            <div class="panel-body">

                            </div>
                          </div>

                        </div><!--/col-3-->
                        <div class="col-sm-9">



                          <div class="tab-content">
                            <div class="tab-pane active" id="home">
                                <hr>



                                      <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="first_name"><h4> Name</h4></label>
                                              <input type="text" class="form-control" name="name" id="name" placeholder=" name" value="<?php echo $name;?>" >
                                          </div>
                                      </div>


                                      <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="phone"><h4>E-Mail</h4></label>
                                              <input type="text" disabled class="form-control" name="emaila" id="emaila" placeholder="email" value="<?php echo $email;?>" >

                                          </div>
                                      </div>
                            <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="email"><h4>Address 1</h4></label>
                                              <input type="text" class="form-control" name="address1" id="address1" value="<?php echo $address1;?>">
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-xs-6">
                                             <label for="mobile"><h4>Mobile</h4></label>

                                              <label class="form-control" name="phone" id="phone"><h5><?php echo $phone;?></h5></label>
                                          </div>
                                      </div>

                                     <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="email"><h4>Address 2</h4></label>
                                              <input type="text" class="form-control" id="address2" name="address2" placeholder="somewhere" value="<?php echo $address2;?>" >
                                          </div>
                                      </div>
                                      <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="email"><h4>City</h4></label>
                                              <input type="text" class="form-control" id="city" name="city" placeholder="somewhere" value="<?php echo $city;?>" >
                                          </div>
                                      </div>

                                      <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="password"><h4>Pin Code</h4></label>
                                              <input type="number" class="form-control" name="pincode" id="pincode" placeholder="pincode" value="<?php echo $pincode;?>" >
                                          </div>
                                      </div>
                                       <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="email"><h4>District</h4></label>
                                              <select class="form-control" name="districta">
                                              <option value="<?php echo $districtida;?>"><?php echo $districtnamea;?></option>
                                              <?php
											  $count=1;
											  foreach($diss as $row)
											  {
												  $districtname=$row->district_name;
							 					  $districtid=$row->district_id;
											  ?>

                                                     <option value="<?php echo $districtid;?>"><?php echo $districtname;?></option>
                                               <?php
											   $count++;
											  }
											  ?>

                                                   </select>

                                          </div>
                                      </div>

                                       <div class="form-group">

                                          <div class="col-xs-6">
                                            <label for="password2"><h4>Pancard</h4></label>
                                             <input type="text" class="form-control" name="pancard" id="pancard" value="<?php echo $pancard;?>">

                                          </div>
                                      </div>
                                      <div class="form-group">

                                          <div class="col-xs-6">
                                            <label for="last_name"><h4>License number</h4></label>
                                              <input type="text" class="form-control" name="licence" id="licence" value="<?php echo $licence;?>">
                                          </div>
                                      </div>

                                      <div class="form-group">

                                          <div class="col-xs-6">
                                            <label for="password2"><h4>Experience</h4></label>
                                              <input type="number" class="form-control" name="experience" id="experience" value="<?php echo $experience;?>" >
                                          </div>
                                      </div>
                                      <div class="form-group">
                                           <div class="col-xs-12">
                                                <br>
                                                <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i>Save</button>
                                                <button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                                            </div>
                                      </div>
                                </form>


                              <?php }?>
                              <hr>

                             </div><!--/tab-pane-->

                          </div><!--/tab-content-->

                        </div><!--/col-9-->
                    </div><!--/row-->











                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="<?php echo base_url('js/jquery.min.js');?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo base_url('js/metisMenu.min.js');?>"></script>

        <!-- DataTables JavaScript -->
        <script src="<?php echo base_url('js/dataTables/jquery.dataTables.min.js');?>"></script>
        <script src="<?php echo base_url('js/dataTables/dataTables.bootstrap.min.js');?>"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo base_url('js/startmin.js');?>"></script>
    </body>
</html>
<script>
$(document).ready(function() {


    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.avatar').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }


    $(".file-upload").on('change', function(){
        readURL(this);
    });
});
</script>
<?php
}
else
{
	$CI->index();

}
?>
