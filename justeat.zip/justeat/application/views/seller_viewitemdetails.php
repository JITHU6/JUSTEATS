<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Justeats-Item Detailes </title>
    <?php include 'adminstyle.php' ?> 
    <body>

        <div id="wrapper">

            <!-- Navigation -->
             <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo site_url('controller/seller_home');?>">Seller</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> Seller</a></li>
                </ul>
				
                <ul class="nav navbar-right navbar-top-links">
                    
                    <li class="dropdown">
                    	
                         <a class="dropdown-toggle"  href="<?php echo site_url('controller/logout');?>">
                            <i class="fa fa-user fa-fw"></i> logout <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                           
                            <?php /*?><li><a href="<?php echo site_url('controller/logout');?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a><?php */?>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-right navbar-top-links">
                <?php 
								foreach($diss as $row)
								{
									$name=$row->name;
								?>	
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> hi,<?php echo $name;?></a></li>
                    <?php
                    }
                    ?>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                </span>
                                </div>
                                <!-- /input-group -->
                            </li>
                           
                          <?php include 'seller_nav.php' ?>
                    </div>
                </div>
            </nav>

            
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Items</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Item Detailes
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="dataTable_wrapper">
                                
                                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>Sl.No</th>
                                                <th>Item Name</th>
                                                <th>Category</th>
                                                <th>Sub Category</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Measuremnet</th>
                                                <th>Stock</th>
                                                <th>Edit/Remove</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
										$count=1;
										foreach($disitem as $row)
										{
											$itemname=$row->item_name;
											$category=$row->category_name;
											$price=$row->price;
											$scategory=$row->subcategory_name;
											$scategoryid=$row->subcategory_id;
											$quantity=$row->quantity;
											$measure=$row->measurement;
											
											$stock=$row->stock;
											$status=$row->item_status;
											$itemid=$row->item_id;
											$q= $quantity + $measure;
											
											?>
											
                                            <tr class="odd gradeX">
                                             <td><?php echo $count;?> </td>
                                                <td><?php echo $itemname;?> </td>
                                                 <td><?php echo $category;?></td> 
                                               <?php
                                                if($scategoryid==0)
                                                {
													?>
                                                <td><?php echo 'null';?></td>
                                                <?php
                                                }
                                                else 
                                                {
													?>
                                                <td><?php echo $scategory;?></td>
                                                <?php
												} 
                                                 ?>
												
                                                 
                                                 <td><?php echo $price;?></td>
                                                <td><?php echo $quantity;?></td>
                                                <td><?php echo $measure;?></td>
                                               <td><?php echo $stock;?></td>
                                              
                                                <form method="post" action="<?php echo site_url('controller/edititem');?>">
                                                <input type="hidden" name="itemblock" value="<?php echo $itemid;?>">
                                                <input type="hidden" name="blockstatus" value="<?php echo $status;?>">
                                                
												 <td class="center"><input type="submit" name="Edititem" class="btn btn-default" value="Edit"></td>
                                                </form>
                                                
                                                    <form method="post" action="<?php echo site_url('controller/removeitem');?>">
                                                <input type="hidden" name="itemblock" value="<?php echo $itemid;?>">
                                                <input type="hidden" name="blockstatus" value="<?php echo $status;?>">
													<td class="center"><input type="submit" name="removeitem" class="btn btn-default" value="Remove"></td>
                                                    
                                                
                                                 </form>
                                            </tr>
                                           
                                           
                                        </tbody>
                                        <?php
										$count++;
										}
										?>
                                    </table>
                                   
                                </div>
                                <!-- /.table-responsive -->
                                
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                
                    <!-- /.col-lg-6 -->
                   
              
                  
                <!-- /.row -->
               
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

            
        </div>

       <!-- jQuery -->
        <script src="<?php echo base_url('js/jquery.min.js');?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo base_url('js/metisMenu.min.js');?>"></script>

        <!-- DataTables JavaScript -->
        <script src="<?php echo base_url('js/dataTables/jquery.dataTables.min.js');?>"></script>
        <script src="<?php echo base_url('js/dataTables/dataTables.bootstrap.min.js');?>"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo base_url('js/startmin.js');?>"></script>

        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>
    </body>
</html>
