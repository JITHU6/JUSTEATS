<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Justeats- Add  Deliverer </title>
        <head>
    <?php include 'adminstyle.php' ?> 
 <script type="text/javascript">
	var pancard=/^[A-Z]{5}[0-9]{4}[A-Z]{1}/;
	var ck_name = /^[A-Za-z0-9 ]{3,20}$/;
	var pat1=/^[0-9](6,6)+$/;
	var addr=/^[a-zA-Z0-9\s,.'-]{3,}$/;
	var pat3=/^[0-9]{6}/;
function validationForm(deliverer)
{
	
	if (document.delivererform.Name.value=="")
	{
        alert ("Please fill in your Name.");
        return false;
    }
	if (!ck_name.test(document.delivererform.Name.value))
	{
        alert ("Please fill in your Correct Name.");
        return false;
    }
	
if (document.delivererform.Phone.value=="")
	{
        alert ("Please fill in your phone.");
		document.delivererform.Phone.value.focus();
        return false;
    }
	if(isNaN(document.delivererform.Phone.value))
	{
		alert("Please check your mobile number");
		document.delivererform.Phone.value.focus();
		return false;
	}
	if(document.delivererform.Phone.value.length!=10)
	{
		alert("Enter 10 digit number");
		document.delivererform.Phone.value.focus();
		return false;
	}	
	
if (document.delivererform.Address1.value=="")
    {
        alert ("Please fill in your Address line 1.");
		document.delivererform.Address1.value.focus();
        return false;
    }
	if (!addr.test(document.delivererform.Address1.value))
    {
        alert ("Please fill in your correct Address line 1.");
		document.delivererform.Address1.value.focus();
        return false;
    }
	
    if (document.delivererform.Address2.value=="")
    {
        alert ("Please fill in your Address line 2.");
		document.delivererform.Address2.value.focus();
        return false;
    }
	if (!addr.test(document.delivererform.Address2.value))
    {
        alert ("Please fill in your correct Address line 2.");
		document.delivererform.Address2.value.focus();
        return false;
    }
	
	
	if (document.delivererform.District.value=="")
    {
        alert ("Please select your District.");
		document.delivererform.District.value.focus();
        return false;
    }
	

    if (document.delivererform.Password.value=="")
    {
        alert ("Please fill in your password.");
		document.delivererform.Password.value.focus();
        return false;
    }
	if (document.delivererform.Password.value=="")
    {
        alert ("Please fill in your confirm password.");
		document.delivererform.Password.value.focus();
        return false;
    } 
}

</script>
    
    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
                       <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo site_url('controller/admin');?>">Justeat Admin</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> Home</a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">
                    <li class="dropdown navbar-inverse">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"> 
                            <i class="fa fa-user fa-fw"></i> <b>Hi,Admin</b>
                        </a>
                      <?php /*?>  <ul class="dropdown-menu dropdown-alerts">
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-comment fa-fw"></i> New Comment
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                                        <span class="pull-right text-muted small">12 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-envelope fa-fw"></i> Message Sent
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-tasks fa-fw"></i> New Task
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-upload fa-fw"></i> Server Rebooted
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="#">
                                    <strong>See All Alerts</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </li>
                        </ul><?php */?>
                    </li>
                    <li class="dropdown">
                       
                       <a href="<?php echo site_url('controller/logout');?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        
                       <?php /*?> <ul class="dropdown-menu dropdown-user">
                            <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                            </li>
                            <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="login.html"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                            </li>
                        </ul><?php */?>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                </span>
                                </div>
                                <!-- /input-group -->
                            </li>
                           
                            <?php include 'admin_nav.php' ?>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="container">
        
      
       
        <div class="container">
        
            <div class="row">
            	
                <div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Add Deliverer</h3>
                        </div>
                        <div class="panel-body">
                            <form role="form" name="delivererform" id="delivererform"   action="<?php echo site_url('controller/insertdeliverer');?>" method="post">
                                <fieldset>
                                  <div class="form-group">
                                        <input class="form-control" placeholder="Name" name="name" id="Name" type="text" autofocus required>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="E-mail" name="email" id="Email" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" autofocus required>
                                    </div>
                                     <div class="form-group">
                                        <input class="form-control" placeholder="Mobile Number" name="mobilenumber" id="Phone" type="number" autofocus required>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Address 1" name="address1" id="Address1" type="text" autofocus required>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Address 2" name="address2" id="Address2" type="text" autofocus required>
                                    </div>
                                      <div class="form-group">
                                          <label for="sel1">District:</label>
                                          <select class="form-control" id="District" name="district">
                                            <option value="">Select district</option>
                                            <?php 
						 foreach($dis as $row)
						 {
							 $districtname=$row->district_name;
							 $districtid=$row->district_id;
							
						?>
                         <option value="<?php echo $districtid;?>" ><?php echo $districtname;?></option>
  						  <?php
						 }
						 ?>
                                          </select>
                                        </div>
                                     

                                    <div class="form-group">
                                     <label for="sel1">Generated Password:</label>
                                        <input class="form-control" placeholder="Generated Password" name="password" id="Password" type="date" value="">
                                    </div>
                                    
                                    <!-- Change this to a button or input when using this as a form -->
                                   <button type="submit" value="dregister" class="btn btn-lg btn-success btn-block" onClick="validationForm()">Register</button>
                                    <div class="alert alert-danger alert-dismissible" role="alert">
  <button type="button" onclick="this.parentNode.parentNode.removeChild(this.parentNode);" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
  <?php 
				  echo $this->session->flashdata('response');
				  ?>
  <strong><i class="fa fa-warning"></i> Hello!</strong> <marquee><p style="font-family: Impact; font-size: 18pt">If you register an employee here, username and password will be sent automatically to the given  E-mail!</p></marquee>
  
</div>
                                   
                                </fieldset>
                            </form>
                        </div>
                    </div>
                    
                </div>
                 
            </div>
            
            <!-- /#page-wrapper -->

            
        </div>

       <!-- jQuery -->

        <script src="<?php echo base_url('js/jquery.min.js');?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo base_url('js/metisMenu.min.js');?>"></script>

        <!-- DataTables JavaScript -->
        <script src="<?php echo base_url('js/dataTables/jquery.dataTables.min.js');?>"></script>
        <script src="<?php echo base_url('js/dataTables/dataTables.bootstrap.min.js');?>"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo base_url('js/startmin.js');?>"></script>

        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>

    </body>
</html>
