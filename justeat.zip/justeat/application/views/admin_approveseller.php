<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="">
<meta name="author" content="">
<title>Justeats- Seller Approval</title>
<?php include 'adminstyle.php' ?>
<body>
<div id="wrapper"> 
  
  <!-- Navigation -->
 <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo site_url('controller/admin');?>">Justeat Admin</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> Home</a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">
                    <li class="dropdown navbar-inverse">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"> 
                            <i class="fa fa-user fa-fw"></i> <b>Hi,Admin</b>
                        </a>
                      <?php /*?>  <ul class="dropdown-menu dropdown-alerts">
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-comment fa-fw"></i> New Comment
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                                        <span class="pull-right text-muted small">12 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-envelope fa-fw"></i> Message Sent
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-tasks fa-fw"></i> New Task
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div>
                                        <i class="fa fa-upload fa-fw"></i> Server Rebooted
                                        <span class="pull-right text-muted small">4 minutes ago</span>
                                    </div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="#">
                                    <strong>See All Alerts</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </li>
                        </ul><?php */?>
                    </li>
                    <li class="dropdown">
                       
                       <a href="<?php echo site_url('controller/logout');?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        
                       <?php /*?> <ul class="dropdown-menu dropdown-user">
                            <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                            </li>
                            <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="login.html"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                            </li>
                        </ul><?php */?>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                </span>
                                </div>
                                <!-- /input-group -->
                            </li>
                           
                            <?php include 'admin_nav.php' ?>
                        </ul>
                    </div>
                </div>
            </nav>

  <div id="page-wrapper">
    <div class="row">
      <div class="col-xs-12">
        <h1 class="page-header">Approve Sellers</h1>
      </div>
      <!-- /.col-lg-12 --> 
    </div>
    <!-- /.row -->
    <div class="row">
      <div class="panel panel-default">
        <div class="panel-heading"> Seller Detailes </div>
        <!-- /.panel-heading -->
        
        <div class="panel-body ">
          <div class="dataTable_wrapper ">
            <div class="row">
              <div class="col-lg-12">
                <div class="table-responsive">
                  <table class="table table-striped table-bordered table-hover " id="dataTables-example">
                    <thead>
                      <tr>
                        <th>Seller Id</th>
                        <th>Name</th>
                        <th>E-mail</th>
                        <th>Phone.No</th>
                        <th>Address 1</th>
                        <th>Address 2</th>
                        <th>Pin Code</th>
                        <th>License Number</th>
                        <th>Experience</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <?php
								$count=1; 
								
								foreach($dis as $row)
								{
									
								$email=$row->email;
								$name=$row->name;
								$phone=$row->rphone;
								$address1=$row->address1;
								$address2=$row->address2;
								$pincode=$row->pincode;
								$experience=$row->experience;
								$licence=$row->licence_number;
								$lid=$row->login_id;
								$status=$row->s_status;
								
						
								?>
                    <tbody>
                      <tr class="odd gradeX">
                        <td><?php echo $count;?></td>
                        <td><?php echo $name;?></td>
                        <td><?php echo $email;?></td>
                        <td><?php echo $phone;?></td>
                        <td ><?php echo $address1;?></td>
                        <td ><?php echo $address2;?></td>
                        <td ><?php echo $pincode;?></td>
                        <td ><?php echo $licence;?></td>
                        <td ><?php echo $experience;?></td>
                        <td class="center"><form method="post" action="<?php echo site_url('controller/approveselleraction')?>" >
                            <input type="hidden" id="blockid" name="blockid" value="<?php echo $lid; ?>" >
                            <input type="hidden" id="blockstatus" name="blockstatus" value="<?php echo $status;?>" >
                            <input type="submit" name="submit" value="Approve">
                          </form></td>
                        <?php 
								$count++;
								}
						?>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <!-- /.table-responsive --> 
          
        </div>
        <!-- /.panel-body --> 
      </div>
      <!-- /.panel --> 
    </div>
    <!-- /.col-lg-12 --> 
  </div>
  
  <!-- /.col-lg-6 --> 
  
  <!-- /.row --> 
  
  <!-- /.row --> 
</div>
<!-- /#page-wrapper -->

</div>
</div>
<!-- /#wrapper --> 

<!-- jQuery --> 
<script src="<?php echo base_url('js/jquery.min.js');?>"></script> 

<!-- Bootstrap Core JavaScript --> 
<script src="<?php echo base_url('js/bootstrap.min.js');?>"></script> 

<!-- Metis Menu Plugin JavaScript --> 
<script src="<?php echo base_url('js/metisMenu.min.js');?>"></script> 

<!-- DataTables JavaScript --> 
<script src="<?php echo base_url('js/dataTables/jquery.dataTables.min.js');?>"></script> 
<script src="<?php echo base_url('js/dataTables/dataTables.bootstrap.min.js');?>"></script> 

<!-- Custom Theme JavaScript --> 
<script src="<?php echo base_url('js/startmin.js');?>"></script> 

<!-- Page-Level Demo Scripts - Tables - Use for reference --> 
<script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>
</body>
</html>
