<?php
$CI=& get_instance();
$a=$CI->sessionin();
if($a)
{
?>
<!DOCTYPE html>
<html>
<head>
<title>Justeats</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script src="<?php echo base_url('js/jquery.min.js');?>"></script>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="<?php echo base_url('css/bootstrap.css');?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url('css/style.css');?>" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="<?php echo base_url('css/font-awesome.css');?>" rel="stylesheet" type="text/css" media="all" />
<!-- //font-awesome icons -->

<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>

</head>

<body>
<!-- header -->
	<div class="agileits_header">
		<div class="w3l_offers">
			<a href="<?php echo site_url('controller/userhome')?>">Taste of Kerala!</a>
		</div>
		<div class="w3l_search">
			<form action="<?php echo site_url('controller/select')?>" method="get">
				<input type="text" name="search" value="Search a product..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search a product...';}" required>
				<input type="submit" value="">
			</form>
		</div>

		<div class="product_list_header  "  style="margin-left:1%">

        <div class="row " style=" margin-left:20%;margin-top:13%;">


            <?php
										$username=$this->session->userdata('id');
                                    $itemlist=$CI->cart($username,0);
									?>
             <a class="btn btn-success btn-sm ml-3" href="<?php echo site_url('controller/checkout')?>">
                    <i class="fa fa-shopping-cart"></i> Cart
                    <span class="badge badge-light"><?php echo $itemlist; ?></span>
                </a>
             </div>
             </div>
             <div class="product_list_header  "  style="margin-left:1%">

        <div class="row " style=" margin-left:20%;margin-top:7%;">


            <?php
										$username=$this->session->userdata('id');
                                    $itemlist=$CI->Order($username,1);
									?>
             <a class="btn btn-success btn-sm ml-3" href="<?php echo site_url('controller/bookeditems')?>">
                    <i class="fa fa-shopping-cart"></i> Order Detailes
                    <span class="badge badge-light"><?php echo $itemlist; ?></span>
                </a>
             </div>
             </div>

         <div class="w3l_header_right" style=" margin-bottom:.1%; margin-left:3%;margin-top:.2%;">
			<ul >
				<li class="dropdown profile_details_drop w3l_header_left">

					<a class="btn btn-success btn-sm ml-3 "  href="<?php echo site_url('controller/logout')?>">
                    <i class="glyphicon glyphicon-log-out"></i> Logout
                    <span class="badge badge-light"></span>
                </a>
				</li>
			</ul>
		</div>


	<div class="w3l_header_right1">
			<h2><a href="<?php echo site_url('controller/contact')?>">Contact Us</a></h2>
		</div>
		<div class="clearfix"> </div>
	</div>
<!-- script-for sticky-nav -->
	<script>
	$(document).ready(function() {
		 var navoffeset=$(".agileits_header").offset().top;
		 $(window).scroll(function(){
			var scrollpos=$(window).scrollTop();
			if(scrollpos >=navoffeset){
				$(".agileits_header").addClass("fixed");
			}else{
				$(".agileits_header").removeClass("fixed");
			}
		 });

	});
	</script>
<!-- //script-for sticky-nav -->
	<div class="logo_products">
		<div class="container">
			<div class="w3ls_logo_products_left">
				<!--<h1><a href="index.html"><span>Grocery</span> Store</a></h1>-->
                <img src="<?php echo base_url('images/logo.png');?>">
			</div>
			<div class="w3ls_logo_products_left1">
				<ul class="special_items">
					<!--<li><a href="events.html">Events</a><i>/</i></li>-->
					<li><a href="<?php echo site_url('controller/about')?>">About Us</a><i>/</i></li>
					<li><a href="#">Best Deals</a><i>/</i></li>


					<!--<li><a href="services.html">Services</a></li>-->
				</ul>
			</div>
			<div class="w3ls_logo_products_left1">
				<ul class="phone_email">
					<li><i class="fa fa-phone" aria-hidden="true"></i>+919497609019</li>
					<li><i class="fa fa-envelope-o" aria-hidden="true"></i><a href="mailto:store@justeats.com">store@justeats.com</a></li>&nbsp;&nbsp;&nbsp;&nbsp;
                     <?php
								foreach($dis as $row)
								{
									$name=$row->name;
								?>
                    <li><a href="#"><h4><b><i class="fa fa-user fa-fw"></i> Welcome <?php echo $name?></b></h4></a></li>
                    <?php
                    }
                    ?>
				</ul>

			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //header -->
<!-- products-breadcrumb -->
	<div class="products-breadcrumb">
		<div class="container">
			<ul>
				<li><i class="fa fa-home" aria-hidden="true"></i><a href="<?php echo site_url('controller/userhome')?>">Home</a><span>|</span></li>
				<li>Checkout</li>
			</ul>
		</div>
	</div>
<!-- //products-breadcrumb -->

		<div class="w3l_banner_nav_right">
<!-- about -->
		<div class="privacy about">
<form name="totalform" action="<?php echo site_url('controller/booking_confirm');?>" method="post">
			<div class="row">
            <h3>Chec<span>kout</span></h3>

	      <div class=" col-md-12 checkout-right">
					<h4>Your shopping cart contains: <span></span></h4>
                   <font color="#FF0000" size="+2"> <?php echo $this->session->flashdata('response');?></font>

				<table class="timetable_sub" id="mytable">
					<thead>
						<tr>
							<th>SL No.</th>
							<th>Product</th>

							<th>Product Name</th>
							<th>Quantity</th>
                            <th>Price per packet</th>
							<th>total Price</th>
							<th>Remove</th>
						</tr>
					</thead>
                    <tbody>
                    <?php
					$count=0;
					$data=array();
					$to=0;
					foreach($diss as $row)
					{
						$prodid=$row->product_id;
						$booking_id=$row->booking_id;
						$name=$row->item_name;
						$number=$row->number_ofpacket;
						$cust_id=$row->cust_id;
						$image=$row->photo;
						$price=$row->price;
						$t=$number*$price;
						$to+=$t;
						$count=$count+1;
						$data=$row->booking_id;
						//echo $booking_id[];
					?>

					<tr class="rem1">

						<td class="invert"><?php echo $count; ?></td>
						<td class="invert-image"><a href="#"><img src="../../images/products/<?php echo $image; ?>" alt="<?php echo $image; ?>" class="img-responsive"></a></td>
						<td class="invert"><?php echo $name; ?></td>
                        <td class="invert"><input type="hidden" value="<?php echo $booking_id; ?>" id="cid" name="cid">
                        <input type="hidden" value="<?php echo $cust_id; ?>"  name="custid">

		<select class="form-control qty" id="<?php echo $booking_id; ?>"  name="qty" cid="<?php echo $booking_id; ?>" onChange="getSubcategory(this.value,this.id,this.jithu)">

           <option value="<?php echo $number; ?>"><?php echo $number; ?></option>
            <option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
		</select>

						</td>
						<script type='text/javascript'>


  function getSubcategory(t,n)
  {

      // AJAX request

	 var a=$('#cid').val();
	  var v=$('#qty').val();
		//var to=$('#to').val();
      $.ajax({
        url:'<?php echo site_url('controller/booking_confirm').'/';?>',
        type: 'POST',
        data: { cid:n,qty:t},
        success: function(response){


			}
     });
   }
   </script>
						<td class="invert"><input type="text" id="price" name="price"  class="price"  value="<?php echo $price; ?>" style="text-align:center;border:hidden;background-color:#FFF;" ></td>

						<td class="invert ">
							 <input type="text" name="total"   class="total" disabled value="<?php echo $t; ?>" >
						</td>

						<td class="invert">
							<div class="rem">
								<div >
                                <form name="remove" action="<?php echo site_url('controller/removebooking')?>" method="post">

                                <input type="hidden" name="bkid" value="<?php echo $booking_id; ?>">
                                <input type="submit" class="fa-times close" name="remove" value="Remove">
                                </form>

                                 </div>
							</div>

						</td>
					</tr>
					<?php
					}
					?>
                    <tr class="rem1">

                    <td colspan='4' class="invert ">Total</td>
                    <td class="invert " ><input type="number" name="txtsum" id="txtsum"  disabled style=" font-weight:400; border:hidden;background-color:#FFF;"></td>
                    <td class="invert" id="gtotal"><input type="number" name="txtname" id="txtname" value="<?php echo $to; ?>" disabled style=" font-weight:400; border:hidden;background-color:#FFF;"></td>

                    </tr>
				</tbody></table>

			</div>
           </div>

            <div class="row">
			<div class=" checkout-left">
				<div class="col-md-3 checkout-left-basket">
					<h4><a href="<?php echo site_url('controller/userhome')?>" style="color:#FFF;">Continue to basket</a></h4>

					</div>
                    </div>
                    <div class=" checkout-left">
			<div class="col-md-5 checkout-left-basket">



								<!--<h4><input type="submit" name="bookingconfirm" value="CONTINUE PAYMENT" style=" border:hidden;background-color:transparent;"></h4>	-->
						<h4>
						<input type="submit" name="updatesubmit" style=" border: none;background:none;" value="CONTINUE PAYMENT"></h4>
					</div>
					</form>
                    </div>
				<div class="clearfix"> </div>


            </div>


       </div></div>



        </div></div>

<!-- //about -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->


			<div class="wthree_footer_copy">
				<p>© 2018 Justeats. All rights reserved | Design by <a href="<?php echo site_url('controller/index')?>">Justeats</a></p>
			</div>




<!-- js -->

<!-- //js -->
<!-- script-for sticky-nav -->
	<script>
	$(document).ready(function() {
		 var navoffeset=$(".agileits_header").offset().top;
		 $(window).scroll(function(){
			var scrollpos=$(window).scrollTop();
			if(scrollpos >=navoffeset){
				$(".agileits_header").addClass("fixed");
			}else{
				$(".agileits_header").removeClass("fixed");
			}
		 });

	});
	</script>
<!-- //script-for sticky-nav -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo base_url('js/move-top.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/easing.js');?>"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- Bootstrap Core JavaScript -->
<script src="<?php base_url('js/bootstrap.min.js');?>"></script>
<script>
$(document).ready(function(){
    $(".dropdown").hover(
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');
        }
    );
});
</script>
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

			});
	</script>
<!-- //here ends scrolling icon -->
<script src="<?php base_url('js/minicart.js');?>"></script>
<script>
		paypal.minicart.render();

		paypal.minicart.cart.on('checkout', function (evt) {
			var items = this.items(),
				len = items.length,
				total = 0,
				i;

			// Count the number of each item in the cart
			for (i = 0; i < len; i++) {
				total += items[i].get('quantity');
			}

			if (total < 3) {
				alert('The minimum order quantity is 3. Please add more to your shopping cart before checking out');
				evt.preventDefault();
			}
		});

	</script>
    <script type="text/javascript">
		$(document).ready(function(){


    $('.qty').each(function() {
        $(this).change(function() {
        	update_amounts();
			getTotal();
			document.getElementById("txtsum").disabled = true;
    	});
    });
});


function update_amounts()
{
    var sum = 0.0;

    $('#mytable > tbody  > tr ').each(function() {
        var qty = $(this).find('option:selected').val();

        var price = $(this).find('.price').val();
        var amount = (qty*price);
        sum+=amount;
        $(this).find('.total').val(''+amount);
		//var total= $(this).find('.total').val();
    });

    //just update the total to sum

	$('.sum').text(sum);

}

function getTotal(){
    var totala = 0;
    $('.total').each(function(){

		if(!isNaN(parseInt($(this).val()))){
			//alert(parseInt($(this).html()));
			totala += parseInt($(this).val());
		}

	//	alert(totala);
    });

    $('#txtname').val(totala);


}


</script>
</body>
</html>
<?php
}
else
{
	$CI->index();

}
?>
