<?php
$CI=& get_instance();
$a=$CI->sessionin();
if($a)
{
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Justeats Seller Profile </title>

        <?php include 'adminstyle.php' ?>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

      <script type="text/javaScript">
     function validate_dropdown(){

		  if (document.registrationForm.item_name.value=="")
    {
        alert ("Please enter the item name.");
		document.registrationForm.item_name.value.focus();
        return false;
    }
	 if (document.registrationForm.price.value=="")
    {
        alert ("Please enter the item price.");
		document.registrationForm.price.value.focus();
        return false;
    }
	if (document.registrationForm.stock.value=="")
    {
        alert ("Please enter the stock you have.");
		document.registrationForm.stock.value.focus();
        return false;
    }
	if (document.registrationForm.quantity.value=="")
    {
        alert ("Please enter the quantity in the packet/Number of  items in the packet.");
		document.registrationForm.quantity.value.focus();
        return false;
    }


		 if (document.registrationForm.category.value=="0")
    {
        alert ("Please select your category.");
		document.registrationForm.category.value.focus();
        return false;
    }

	if (document.registrationForm.subcategory.value=="0")
    {
        alert ("Please select your subcategory.");
		document.registrationForm.subcategory.value.focus();
        return false;
    }

	 if (document.registrationForm.discription.value=="")
    {
        alert ("Please provide the description of your product.");
		document.registrationForm.discription.value.focus();
        return false;
    }

    }
	</script>
	  <script>
//    // Run on page load
//    window.onload = function() {
//
//        // If sessionStorage is storing default values (ex. name), exit the function and do not restore data
//
//
//        // If values are not blank, restore them to the fields
//        var item_name = sessionStorage.getItem('item_name');
//        if (item_name !== null) $('#item_name').val(item_name);
//
//       var subcategory = sessionStorage.getItem('subcategory');
//        if (subcategory !== null) $('#subcategory').val(subcategory);
//
//		var category = sessionStorage.getItem('category');
//        if (category !== null) $('#category').val(category);
//
//		var measure = sessionStorage.getItem('measure');
//        if (measure !== null) $('#measure').val(measure);
//
//        var price= sessionStorage.getItem('price');
//        if (price!== null) $('#price').val(price);
//
//        var quantity= sessionStorage.getItem('quantity');
//        if (quantity!== null) $('#quantity').val(quantity);
//
//		 var measure= sessionStorage.getItem('measure');
//        if (measure!== null) $('#measure').val(measure);
//
//		var discription= sessionStorage.getItem('discription');
//        if (discription!== null) $('#discription').val(discription);
//    }
//
//    // Before refreshing the page, save the form data to sessionStorage
//    window.onbeforeunload = function() {
//        sessionStorage.setItem("item_name", $('#item_name').val());
//        sessionStorage.setItem("category", $('#category').val());
//		 sessionStorage.setItem("subcategory", $('#subcategory').val());
//		 sessionStorage.setItem("measure", $('#measure').val());
//        sessionStorage.setItem("price", $('#price').val());
//        sessionStorage.setItem("quantity", $('#quantity').val());
//		 sessionStorage.setItem("measure", $('#measure').val());
//		  sessionStorage.setItem("discription", $('#discription').val());
//    }
//
</script>
 <script type='text/javascript'>
  // baseURL variable
 // var baseURL= "<?php echo base_url();?>";

  function getSubcategory(category)
  {
	 // alert(category);
      // AJAX request
      $.ajax({
        url:'<?php echo site_url('controller/getsubcategory').'/';?>'+category,
        type: 'POST',
        data: category='category',
        dataType: 'json',
        success: function(response){
			//alert(JSON.stringify(response));

          // Remove options
         $('#subcategory').find('option').eq(0).remove();


          // Add options
          $.each(response,function(seller_additem,data){


             $('#subcategory').append('<option value="'+data['subcategory_id']+'">'+data['subcategory_name']+'</option>');
          });
        }
     });
   }

  /* // Department change
   $('#sel_depart').change(function(){
     var department = $(this).val();

     // AJAX request
     $.ajax({
       url:'<?=base_url()?>index.php/User/getDepartmentUsers',
       method: 'post',
       data: {department: department},
       dataType: 'json',
       success: function(response){

         // Remove options
         $('#sel_user').find('option').not(':first').remove();

         // Add options
         $.each(response,function(index,data){
           $('#sel_user').append('<option value="'+data['id']+'">'+data['name']+'</option>');
         });
       }
    });
  });

 });*/

 </script>



</script>


    </script>
    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
             <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo site_url('controller/seller_home');?>">Seller</a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> Seller</a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">

                    <li class="dropdown">

                         <a class="dropdown-toggle"  href="<?php echo site_url('controller/logout');?>">
                            <i class="fa fa-user fa-fw"></i> logout <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">

                            <?php /*?><li><a href="<?php echo site_url('controller/logout');?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a><?php */?>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-right navbar-top-links">
                <?php
								foreach($diss as $row)
								{
									$name=$row->name;
								?>
                    <li><a href="#"><i class="fa fa-home fa-fw"></i> hi,<?php echo $name;?></a></li>
                    <?php
                    }
                    ?>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li class="sidebar-search">
                                <div class="input-group custom-search-form">
                                    <input type="text" class="form-control" placeholder="Search...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fa fa-search"></i>
                                        </button>
                                </span>
                                </div>
                                <!-- /input-group -->
                            </li>

                          <?php include 'seller_nav.php' ?>
                    </div>
                </div>
            </nav>






            <div id="page-wrapper">


           <hr>

                <div class="container bootstrap snippet col-lg-10">
                    <div class="row">
                        <div class="col-sm-10"><h1>Add Item</h1></div>
                        <div class="col-sm-2"><a href="/users" class="pull-right"><img  class="img-circle img-responsive" src=""></a></div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3"><!--left col-->


                <form class="form" action="<?php echo site_url('controller/additem');?>" method="post" name="registrationForm" id="registrationForm" enctype="multipart/form-data">

                      <div class="text-center">

                        <img src="<?php echo base_url('images/logo.png');?>"   name="image" id="image" class="avatar img-circle img-thumbnail" >

                        <h6>Upload photo of Item</h6>
                        <input type="file" name="itemimage" id="itemimage" class="text-center center-block file-upload"  accept=".png, .jpg, .jpeg,.JPG" required>

                        <font color="#FF0000" size="+1" face="Courier New, Courier, monospace">
                        <?php
						 echo $this->session->flashdata('response');
            ?>

                        </font>
                      </div></hr><br>



                        </div><!--/col-3-->
                        <div class="col-sm-9">



                          <div class="tab-content">
                            <div class="tab-pane active" id="home">
                                <hr>

                                      <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="first_name"><h4>Item Name</h4></label>
                                              <input type="text" class="form-control" name="item_name" id="item_name" placeholder="Item Name" required>
                                          </div>
                                      </div>
                                      <div class="form-group">

                                          <div class="col-xs-6">
                                            <label for="last_name"><h4>Category</h4></label>

                                            <select name="category" id="category" class="form-control" onChange="getSubcategory(this.value)">
                                            <option value="0" selected>-- Select category --</option>
                                             <?php
										  foreach($dis as $row)
										  {
											  $categoryname=$row->category_name;
											  $categoryid=$row->category_id;
										  ?>

                                            <option value="<?php echo $categoryid;?>"><?php echo $categoryname;?></option>
                                            <?php
										  }
										  ?>
                                            </select>

                                          </div>

                                      </div>



                                      <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="phone"><h4>Price</h4></label>
                                              <input type="number" class="form-control" name="price" id="price"  placeholder="enter price of the item in Rupees." required >
                                          </div>
                                      </div>
                                       <div class="form-group">

                                          <div class="col-xs-6">
                                            <label for="last_name"><h4>Sub Category</h4></label>

                                            <select name="subcategory" id="subcategory" class="form-control">
                                             <option value="0" selected>-- Select subcategory --</option>

                                            </select>


                                          </div>

                                      </div>
                                      <div class="form-group">
                                          <div class="col-xs-6">
                                             <label for="mobile"><h4>Stock</h4></label>
                                              <input type="number" class="form-control" name="stock" id="stock" placeholder="enter the stock of the item in numbers." min="1" step="1" required >
                                          </div>
                                      </div>
                          				<div class="form-group">

                                          <div class="col-xs-6  " >
                                              <label for="email"><h4>Quantity</h4></label>

                                              <input type="number" class="form-control" id="quantity" name="quantity" placeholder="enter quantity of the item in gram's." >

                                           <div class="col-xs-6" >
                                            <select name="measure" id="measure"  class="form-control"  >
                                            <option value="Grams">Grams</option>
                                            <option value="Kilo Grams">Kilo Grams</option>
                                            <option value="No.s">No.s</option>

                                            </select>
                                          </div>
                                          </div>

                                      </div>

                                      <div class="form-group">
                                          <div class="col-xs-6">
                                             <label for="mobile"><h4>Date</h4></label>
                                              <input type="text" class="form-control" name="date" id="date" value="<?php echo date("Y.m.d");?>" >
                                          </div>
                                      </div>


                                      <div class="form-group">

                                          <div class="col-xs-6">
                                              <label for="email"><h4>Discription</h4></label>

                                              <textarea class="form-control" rows="5" name="discription" id="discription" required></textarea>
                                          </div>
                                      </div>




                                      <div class="form-group">
                                           <div class="col-xs-12">
                                                <br>


                                                <button class="btn btn-lg btn-success" type="submit" name="submitform" id="submit" onClick="validate_dropdown()"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                                <button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                                                <script type="text/javascript">
												$('#submit').click(function(){
													$(this).attr('disabled','true');
												});
												</script>
                                            </div>
                                      </div>
                                </form>

                              <hr>

                             </div><!--/tab-pane-->

                          </div><!--/tab-content-->

                        </div><!--/col-9-->
                    </div><!--/row-->

                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="<?php echo base_url('js/jquery.min.js');?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo base_url('js/metisMenu.min.js');?>"></script>

        <!-- DataTables JavaScript -->
        <script src="<?php echo base_url('js/dataTables/jquery.dataTables.min.js');?>"></script>
        <script src="<?php echo base_url('js/dataTables/dataTables.bootstrap.min.js');?>"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo base_url('js/startmin.js');?>"></script>
    </body>
</html>
<script>
$(document).ready(function() {


    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.avatar').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }


    $(".file-upload").on('change', function(){
        readURL(this);
    });
});
</script>
<script>
$(document).ready(function() {


    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.avatar').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }


    $(".file-upload").on('change', function(){
        readURL(this);
    });
});
</script>

<?php
}
else
{
	$CI->index();

}
?>
