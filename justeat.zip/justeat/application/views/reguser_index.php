<?php
$CI=& get_instance();
$a=$CI->sessionin();
if($a)
{
?>
<!DOCTYPE html>
<html>
<head>
<title>Justeats</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />


<link href="<?php echo base_url('css/bootstrap.css');?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url('css/style.css');?>" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>

<!-- font-awesome icons -->
<link href="<?php echo base_url('css/font-awesome.css');?>" rel="stylesheet" type="text/css" media="all" />
<!-- //font-awesome icons -->
<!-- js -->
<script src="<?php echo base_url('js/jquery-1.11.1.min.js');?>"></script>
<script src='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic'></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo base_url('js/move-top.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/easing.js');?>"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->

</head>
<body>
	<!-- header -->
  	<div class="agileits_header">
  		<div class="w3l_offers">
  			<a href="<?php echo site_url('controller/userhome')?>">Taste of Kerala!</a>
  		</div>
  		<div class="w3l_search">
  			<form action="<?php echo site_url('controller/select')?>" method="get">
  				<input type="text" name="search" value="Search a product..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search a product...';}" required>
  				<input type="submit" value="">
  			</form>
  		</div>

  		<div class="product_list_header  "  style="margin-left:1%">

          <div class="row " style=" margin-left:20%;margin-top:13%;">


              <?php
  										$username=$this->session->userdata('id');
                                      $itemlist=$CI->cart($username,0);
  									?>
               <a class="btn btn-success btn-sm ml-3" href="<?php echo site_url('controller/checkout')?>">
                      <i class="fa fa-shopping-cart"></i> Cart
                      <span class="badge badge-light"><?php echo $itemlist; ?></span>
                  </a>
               </div>
               </div>
               <div class="product_list_header  "  style="margin-left:1%">

          <div class="row " style=" margin-left:20%;margin-top:7%;">


              <?php
  										$username=$this->session->userdata('id');
                                      $itemlist=$CI->Order($username,1);
  									?>
               <a class="btn btn-success btn-sm ml-3" href="<?php echo site_url('controller/bookeditems')?>">
                      <i class="fa fa-shopping-cart"></i> Order Detailes
                      <span class="badge badge-light"><?php echo $itemlist; ?></span>
                  </a>
               </div>
               </div>

           <div class="w3l_header_right" style=" margin-bottom:.1%; margin-left:3%;margin-top:.2%;">
  			<ul >
  				<li class="dropdown profile_details_drop w3l_header_left">

  					<a class="btn btn-success btn-sm ml-3 "  href="<?php echo site_url('controller/logout')?>">
                      <i class="glyphicon glyphicon-log-out"></i> Logout
                      <span class="badge badge-light"></span>
                  </a>
  				</li>
  			</ul>
  		</div>


  	<div class="w3l_header_right1">
  			<h2><a href="<?php echo site_url('controller/contact')?>">Contact Us</a></h2>
  		</div>
  		<div class="clearfix"> </div>
  	</div>
  <!-- script-for sticky-nav -->
  	<script>
  	$(document).ready(function() {
  		 var navoffeset=$(".agileits_header").offset().top;
  		 $(window).scroll(function(){
  			var scrollpos=$(window).scrollTop();
  			if(scrollpos >=navoffeset){
  				$(".agileits_header").addClass("fixed");
  			}else{
  				$(".agileits_header").removeClass("fixed");
  			}
  		 });

  	});
  	</script>
  <!-- //script-for sticky-nav -->
  	<div class="logo_products">
  		<div class="container">
  			<div class="w3ls_logo_products_left">
  				<!--<h1><a href="index.html"><span>Grocery</span> Store</a></h1>-->
                  <img src="<?php echo base_url('images/logo.png');?>">
  			</div>
  			<div class="w3ls_logo_products_left1">
  				<ul class="special_items">
  					<!--<li><a href="events.html">Events</a><i>/</i></li>-->
  					<li><a href="<?php echo site_url('controller/about')?>">About Us</a><i>/</i></li>
  					<li><a href="#">Best Deals</a><i>/</i></li>


  					<!--<li><a href="services.html">Services</a></li>-->
  				</ul>
  			</div>
  			<div class="w3ls_logo_products_left1">
  				<ul class="phone_email">
  					<li><i class="fa fa-phone" aria-hidden="true"></i>+919497609019</li>
  					<li><i class="fa fa-envelope-o" aria-hidden="true"></i><a href="mailto:store@justeats.com">store@justeats.com</a></li>&nbsp;&nbsp;&nbsp;&nbsp;
                       <?php
  								foreach($dis as $row)
  								{
  									$name=$row->name;
  								?>
                      <li><a href="#"><h4><b><i class="fa fa-user fa-fw"></i> Welcome <?php echo $name?></b></h4></a></li>
                      <?php
                      }
                      ?>
  				</ul>

  			</div>
  			<div class="clearfix"> </div>
  		</div>
  	</div>
  <!-- //header --><!-- products-breadcrumb -->
	<div class="products-breadcrumb">
		<div class="container">
			<ul>
				<li><i class="fa fa-home" aria-hidden="true"></i><a href="<?php echo site_url('controller/userhome')?>">Home</a><span>|</span></li>
				<li>Brandeda Foods</li>
			</ul>
		</div>
	</div>
<!-- //products-breadcrumb -->
<!-- banner -->
	<div class="banner">
		<div class="w3l_banner_nav_left">
			<nav class="navbar nav_bottom">
				 <!-- Brand and toggle get grouped for better mobile display -->
				  <div class="navbar-header nav_2">
					  <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
				   </div>
	<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav nav_1">


							<li class="dropdown mega-dropdown active">
								<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown" >Cookies & Crackers<span class="caret"></span></a>
								<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
									<div class="w3ls_vegetables">
										<ul>
											<li><a href="<?php echo site_url('controller/Biscuits')?>" >Biscuits </a></li>
											<li><a href="<?php echo site_url('controller/Cookies')?>">Cookies </a></li>
											<li><a href="<?php echo site_url('controller/Straws ')?>">Straws </a></li>
										</ul>
									</div>
								</div>
							</li>

							<li class="dropdown mega-dropdown active">
								<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Antipasti<span class="caret"></span></a>
								<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
									<div class="w3ls_vegetables">
										<ul>
											<li><a href="<?php echo site_url('controller/Olives ')?>"> Olives, Capers & Tapenades
	</a></li>

											<li><a href="<?php echo site_url('controller/Gherkins ')?>">Gherkins & Jalapenos </a></li>
	                        <li><a href="<?php echo site_url('controller/Sundried ')?>">Sundried Tomatoes & Others
	</a></li>
										</ul>
									</div>
								</div>
							</li>




	<li class="dropdown mega-dropdown active">
		<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Dry Snacks<span class="caret"></span></a>
		<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
			<div class="w3ls_vegetables">
				<ul>
					<li><a href="<?php echo site_url('controller/Chips ')?>"> Chips , Nachos & Crisps</a></li>

					<li><a href="<?php echo site_url('controller/Dryfruits ')?>">Dry Fruits & Nuts </a></li>
							<li><a href="<?php echo site_url('controller/Dryseeds ')?>">Dry Seeds</a></li>
							<li><a href="<?php echo site_url('controller/DrySnacks ')?>">Indian & Dry Snacks </a></li>

				</ul>
			</div>
		</div>
	</li>


	<li class="dropdown mega-dropdown active">
		<a href="#" class="dropdown-toggle text-uppercase" data-toggle="dropdown">Chocolates<span class="caret"></span></a>
		<div class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
			<div class="w3ls_vegetables">
				<ul>
					<li><a href="<?php echo site_url('controller/Funsize ')?>"> Funsize Packs & Snacksize Bars</a></li>

					<li><a href="<?php echo site_url('controller/Milk ')?>">Milk, Dark & Mint Chocolates </a></li>
							<li><a href="<?php echo site_url('controller/Fudge ')?>">Fudge & Truffles</a></li>
							<li><a href="<?php echo site_url('controller/Bouquettes ')?>">Gift Packs & Bouquettes </a></li>

				</ul>
			</div>
		</div>
	</li>

						</ul>
					 </div>
	                </nav>
		</div>
               <!-- /.navbar-collapse -->

		<div class="w3l_banner_nav_right">
			<section class="slider">
				<div class="flexslider">
					 <ul class="slides">
						<li>
							<div class="w3l_banner_nav_right_banner">
								<h3>Make your <span>food</span> with Spicy.</h3>
								<div class="more">
									<a href="#" class="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a>
								</div>
							</div>
						</li>
						<li>
							<div class="w3l_banner_nav_right_banner1">
								<h3>Make your <span>food</span> with Spicy.</h3>
								<div class="more">

									<a href="#" class="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a>
								</div>
							</div>
						</li>
						<li>
							<div class="w3l_banner_nav_right_banner2">
								<h3>upto <i>50%</i> off.</h3>
								<div class="more">
									<a href="#" class="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</section>
			<!-- flexSlider -->
				<link rel="stylesheet" href="<?php echo base_url('css/flexslider.css');?>" type="text/css" media="screen" property="" />
				<script defer src="<?php echo base_url('js/jquery.flexslider.js')?>"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- banner -->
	<div class="banner_bottom">
			<div class="wthree_banner_bottom_left_grid_sub">
			</div>
			<div class="wthree_banner_bottom_left_grid_sub1">
				<div class="col-md-4 wthree_banner_bottom_left">
					<div class="wthree_banner_bottom_left_grid">
						<img src="<?php echo base_url('images/1.jpg');?>" alt=" " class="img-responsive" />
						<div class="wthree_banner_bottom_left_grid_pos">
							<h4>Discount Offer <span>25%</span></h4>
						</div>
					</div>
				</div>
				<div class="col-md-4 wthree_banner_bottom_left">
					<div class="wthree_banner_bottom_left_grid">
						<img src="<?php echo base_url('images/2.jpg');?>" alt=" " class="img-responsive" />
						<div class="wthree_banner_btm_pos">
							<h3>introducing <span>best store</span> for <i>groceries</i></h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 wthree_banner_bottom_left">
					<div class="wthree_banner_bottom_left_grid">
						<img src="<?php echo base_url('images/HotMochaStick.JPG');?>" alt=" " class="img-responsive" />
						<div class="wthree_banner_btm_pos1">
							<h3>Save <span>Upto</span> $10</h3>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
	</div>
<!-- top-brands -->
	<div class="top-brands">
		<div class="container">
			<h3>Hot Offers</h3>
			<div class="agile_top_brands_grids">
				        <?php
					foreach($diss as $row)
					{
						$itemid=$row->item_id;
						$image=$row->photo;
						$name=$row->item_name;
						$price=$row->price;
					?>
					<div class="col-md-3 w3ls_w3l_banner_left">

						<div class="hover14 column">

						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">


							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block" style="width:100%;height:100%">
										<div class="snipcart-thumb">
                                        	<div  >

											<a href=""><img src="../../images/products/<?php echo $image; ?>" alt="<?php echo $image;?>" class="img-responsive " /></a>
                                            </div>
											<p><?php echo $name;?></p>
											<h4>RS.<?php echo $price;?> <span></span></h4>
										</div>
                                        <div class="snipcart-details">
                                        <form action="<?php echo site_url('controller/view_singleproduct')?>" method="post">
                                        <input type="hidden" value="<?php echo $itemid;?>" name="itemid">
                                        <input type="submit" name="submit" value="LOGIN TO PURCHASE" class="button" />

                                        </form>
                                        </div>



										<!--<div class="snipcart-details">
											<form action="#" method="post">
												<fieldset>
													<input type="hidden" name="cmd" value="_cart" />
													<input type="hidden" name="add" value="1" />
													<input type="hidden" name="business" value=" " />
													<input type="hidden" name="item_name" value="knorr instant soup" />
													<input type="hidden" name="amount" value="3.00" />
													<input type="hidden" name="discount_amount" value="1.00" />
													<input type="hidden" name="currency_code" value="USD" />
													<input type="hidden" name="return" value=" " />
													<input type="hidden" name="cancel_return" value=" " />
													<input type="submit" name="submit" value="Add to cart" class="button" />
												</fieldset>
											</form>
										</div> -->
									</div>
								</figure>
							</div>

						</div>

						</div>

					</div>
                    <?php
					}
                    ?>



				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //top-brands -->
<!-- fresh-vegetables -->

<!-- //fresh-vegetables -->
<!-- newsletter -->
	<div class="newsletter">
		<div class="container">
			<div class="w3agile_newsletter_left">
				<h3>sign up for our newsletter</h3>
			</div>
			<div class="w3agile_newsletter_right">
				<form action="#" method="post">
					<input type="email" name="Email" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" required>
					<input type="submit" value="subscribe now">
				</form>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //newsletter -->
<!-- footer -->
	<div class="footer">
		<div class="container">
		<!--	<div class="col-md-3 w3_footer_grid">
				<h3>information</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="events.html">Events</a></li>
					<li><a href="about.html">About Us</a></li>
					<li><a href="products.html">Best Deals</a></li>
					<li><a href="services.html">Services</a></li>
					<li><a href="short-codes.html">Short Codes</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3_footer_grid">
				<h3>policy info</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="faqs.html">FAQ</a></li>
					<li><a href="privacy.html">privacy policy</a></li>
					<li><a href="privacy.html">terms of use</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3_footer_grid">
				<h3>what in stores</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="pet.html">Pet Food</a></li>
					<li><a href="frozen.html">Frozen Snacks</a></li>
					<li><a href="kitchen.html">Kitchen</a></li>
					<li><a href="products.html">Branded Foods</a></li>
					<li><a href="household.html">Households</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3_footer_grid">
				<h3>twitter posts</h3>
				<ul class="w3_footer_grid_list1">
					<li><label class="fa fa-twitter" aria-hidden="true"></label><i>01 day ago</i><span>Non numquam <a href="#">http://sd.ds/13jklf#</a>
						eius modi tempora incidunt ut labore et
						<a href="#">http://sd.ds/1389kjklf#</a>quo nulla.</span></li>
					<li><label class="fa fa-twitter" aria-hidden="true"></label><i>02 day ago</i><span>Con numquam <a href="#">http://fd.uf/56hfg#</a>
						eius modi tempora incidunt ut labore et
						<a href="#">http://fd.uf/56hfg#</a>quo nulla.</span></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
			<div class="agile_footer_grids">
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						<h4>100% secure payments</h4>
						<img src="images/card.png" alt=" " class="img-responsive" />
					</div>
				</div>
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						<h5>connect with us</h5>
						<ul class="agileits_social_icons">
							<li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#" class="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#" class="dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>-->
			<div class="wthree_footer_copy">
				<p>© 2018 Justeats. All rights reserved | Design by <a href="<?php echo site_url('controller/index')?>">Justeats</a></p>
			</div>
		</div>
	</div>
<!-- //footer -->
<!-- Bootstrap Core JavaScript -->
<script src="<?php base_url('js/bootstrap.min.js');?>"></script>
<script>
$(document).ready(function(){
    $(".dropdown").hover(
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');
        }
    );
});
</script>

<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/

			$().UItoTop({ easingType: 'easeOutQuart' });

			});
	</script>
<!-- //here ends scrolling icon -->
<script src="<?php base_url('js/minicart.js');?>"></script>
<script>
		paypal.minicart.render();

		paypal.minicart.cart.on('checkout', function (evt) {
			var items = this.items(),
				len = items.length,
				total = 0,
				i;

			// Count the number of each item in the cart
			for (i = 0; i < len; i++) {
				total += items[i].get('quantity');
			}

			if (total < 3) {
				alert('The minimum order quantity is 3. Please add more to your shopping cart before checking out');
				evt.preventDefault();
			}
		});

	</script>

</body>
</html>
<?php
}
else
{
	$CI->index();

}
?>
