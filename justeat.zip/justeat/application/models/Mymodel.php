<?php
class Mymodel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	//user registraion details insert
	function insertdistrict($userdataa)
	{
		$this->db->insert('tbl_district',$userdataa);
		$did=$this->db->insert_id();
		return $did;
	}
	function insertaddress($userdatab)
	{
		$this->db->insert('tbl_address',$userdatab);
		$aid=$this->db->insert_id();
		return $aid;
	}
	function insertreg($userdatac)
	{
		$this->db->insert('tbl_registration',$userdatac);
		$rid=$this->db->insert_id();
		return $rid;
	}
	function insertlogin($userdatad)
	{
		$this->db->insert('tbl_login',$userdatad);
		$lid=$this->db->insert_id();
		return $lid;
	}
	function insertseller($sellerinfo)
	{
		$this->db->insert('tbl_sellerinfo',$sellerinfo);
	}
	function checkseller($logid)
	{
		$querys=$this->db->get_where('tbl_sellerinfo',array('login_id'=>$logid));
		return $querys->result();
	}
	//Check user
	function checkreguser($u_email)
	{
		$querys=$this->db->get_where('tbl_login',array('email'=>$u_email));
		return $querys->result();
	}
	//login
	function loguser($username,$password)
	{

		$querys=$this->db->get_where('tbl_login',array('email'=>$username,'password'=>$password));
		return $querys->result();
	}
	function disuser($username)
	{
		$this->db->join('tbl_sellerinfo','tbl_login.login_id=tbl_sellerinfo.slogin_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');


		$querys=$this->db->get_where('tbl_login',array('email'=>$username));
		return $querys->result();
	}
	function admindisuser($duser)
	{
		$querys=$this->db->get_where('tbl_login',array('email'=>$duser));
		return $querys->result();
	}
	function updateseller($u_name,$username,$u_address1,$u_address2,$u_city,$u_district,$u_pincode,$u_pancard,$u_licence,$u_experience,$image)
	{


		//$this->db->update('tbl_login',array('district_name'=>$u_district,'address1'=>$u_address1,'address2'=>$u_address2,'city'=>$u_city,'pincode'=>$u_pincode,'name'=>$u_name));
		 $this->db->select('user_id');
   		 $this->db->from('tbl_login');
   		 $this->db->where('email',$username);
		 $query =$this->db->get()->row('user_id');
		$this->db->where('user_id',$query);
		$this->db->update('tbl_registration',array('name'=>$u_name));



		 $this->db->select('address_id');
   		 $this->db->from('tbl_registration');
   		 $this->db->where('user_id',$query);
		$query1 = $this->db->get()->row('address_id');
		$this->db->where('address_id',$query1);
		$this->db->update('tbl_address',array('address1'=>$u_address1,'address2'=>$u_address2,'city'=>$u_city,'district_id'=>$u_district,'pincode'=>$u_pincode,'pancard'=>$u_pancard));


		$this->db->select('login_id');
   		 $this->db->from('tbl_login');
   		 $this->db->where('email',$username);
		 $logid =$this->db->get()->row('login_id');


		 $this->db->select('seller_id');
   		 $this->db->from('tbl_sellerinfo');
   		 $this->db->where('slogin_id',$logid);
		$query3 = $this->db->get()->row('seller_id');
		$this->db->where('seller_id',$query3);
		$this->db->update('tbl_sellerinfo',array('licence_number'=>$u_licence,'experience'=>$u_experience,'image'=>$image));



		$this->db->join('tbl_sellerinfo','tbl_login.login_id=tbl_sellerinfo.slogin_id','inner');

		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');

		$querys=$this->db->get_where('tbl_login',array('email'=>$username));

		//$this->db->insert('tbl_district',$userdataa);

	}
	//insert category
	function insertcategory($userdataa)
	{
		$this->db->insert('tbl_category',$userdataa);
		$aid=$this->db->insert_id();
		return $aid;
	}
	//insert item
	function insertitem($userdatab)
	{
		$this->db->insert('tbl_item',$userdatab);
		$itemid=$this->db->insert_id();
		return $itemid;
	}
	function addcategory($category)
	{
		$this->db->insert('tbl_category',$category);
	}
	function checkcategory($categoryname)
	{
		$query=$this->db->get_where('tbl_category',array('category_name'=>$categoryname));
		return $query->result();
	}
	function checksubcategory($categoryname)
	{
		$query=$this->db->get_where('tbl_subcategory',array('subcategory_name'=>$categoryname));
		return $query->result();
	}
	function addsubcategory($category)
	{
		$this->db->insert('tbl_subcategory',$category);

	}
	function displayseller()
	{
		$this->db->join('tbl_sellerinfo','tbl_login.login_id=tbl_sellerinfo.slogin_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		//$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');

		$querys=$this->db->get_where('tbl_login',array('type'=>'Seller'));
		return $querys->result();
	}
	function approvedseller()
	{
		$this->db->join('tbl_login','tbl_sellerinfo.slogin_id=tbl_login.login_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		//$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');

		$querys=$this->db->get_where('tbl_sellerinfo',array('s_status'=>1));
		return $querys->result();
	}
	function approveseller()
	{
		$this->db->join('tbl_login','tbl_sellerinfo.slogin_id=tbl_login.login_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		//$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');

		$querys=$this->db->get_where('tbl_sellerinfo',array('s_status'=>0));
		return $querys->result();
	}
	function approveselleraction($lid,$status)
	{
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');
		$this->db->join('tbl_sellerinfo','tbl_login.login_id=tbl_sellerinfo.slogin_id','inner');
		$querys=$this->db->get_where('tbl_login',array('login_id'=>$lid));
		//return $querys->result();
		 $this->db->select('seller_id');
   		 $this->db->from('tbl_sellerinfo');
   		 $this->db->where('slogin_id',$lid);
		$query3 = $this->db->get()->row('seller_id');
		$this->db->where('seller_id',$query3);
	   $this->db->update('tbl_sellerinfo',array('s_status'=>$status));



	}
	function displayuser()
	{
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		//$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');
		$querys=$this->db->get_where('tbl_login',array('type'=>'Shopper'));
		return $querys->result();

	}
	function adminviewquality()
	{
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');
		$querys=$this->db->get_where('tbl_login',array('type'=>'QChecker'));
		return $querys->result();

	}
	function adminviewdeliverer()
	{
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');
		$querys=$this->db->get_where('tbl_login',array('type'=>'Deliverer'));
		return $querys->result();

	}
	function adminitemdetailes()
	{

		$this->db->join('tbl_category','tbl_item.category_id=tbl_category.category_id','inner');
		$this->db->join('tbl_login','tbl_item.ilogin_id=tbl_login.login_id','inner');

		//$this->db->join('tbl_sellerinfo','tbl_login.login_id=tbl_sellerinfo.slogin_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		//$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		//$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');


		$querys=$this->db->get_where('tbl_item');
		return $querys->result();

	}
	function blockitem($itemid,$status)
	{


		$this->db->where('item_id',$itemid);
		$this->db->update('tbl_item',array('item_status'=>$status));
	}
	function categoryname()
	{
		$query=$this->db->get_where('tbl_category',array('c_status'=>1));
		return $query->result();
	}
	function subcategoryname()
	{
		$query=$this->db->get_where('tbl_subcategory',array('sub_status'=>1));
		return $query->result();
	}
	function districtdetailes()
	{
		$query=$this->db->get('tbl_district');
		return $query->result();
	}
	function admincategorydetailes()
	{

		$this->db->join('tbl_login','tbl_category.s_id=tbl_login.login_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');


		$query=$this->db->get('tbl_category');
		return $query->result();
	}
	function adminsubcategorydetailes()
	{
		$this->db->join('tbl_subcategory','tbl_category.category_id=tbl_subcategory.c_id','inner');

		$this->db->join('tbl_login','tbl_subcategory.s_id=tbl_login.login_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$query=$this->db->get('tbl_category');
		return $query->result();
	}
	function categoryapprove($categoryid,$status)
	{
		$this->db->where('category_id',$categoryid);
		$this->db->update('tbl_category',array('c_status'=>$status));
	}
	function subcategoryapprove($categoryid,$status)
	{
		$this->db->where('subcategory_id',$categoryid);
		$this->db->update('tbl_subcategory',array('sub_status'=>$status));
	}

	function itemimage($itemid)
	{
		$this->db->join('tbl_category','tbl_item.category_id=tbl_category.category_id','inner');
		$this->db->join('tbl_login','tbl_item.ilogin_id=tbl_login.login_id','inner');

		//$this->db->join('tbl_sellerinfo','tbl_login.login_id=tbl_sellerinfo.slogin_id','inner');
		//$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		//$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		//$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');


		$querys=$this->db->get_where('tbl_item',array('item_id'=>$itemid));
		return $querys->result();
	}
	function checkitem($lid,$itemname,$category,$subcategory,$price)
	{
		$qry=$this->db->get_where('tbl_item',array('ilogin_id'=>$lid,'item_name'=>$itemname,'category_id'=>$category,'subcategory_id'=>$subcategory,'price'=>$price));
		return $qry->result();
	}

	function selleritemdetailes($usename)
	{

		$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		//$this->db->join('tbl_login','tbl_item.ilogin_id=tbl_login.login_id','inner');
		//$this->db->join('tbl_subcategory','tbl_category.category_id=tbl_subcategory.c_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('ilogin_id'=>$usename));


		return $qry->result();
	}
	function edititem($itemid)
	{

		//$this->db->join('tbl_category','tbl_item.category_id=tbl_category.category_id','inner');
		//$this->db->join('tbl_login','tbl_item.ilogin_id=tbl_login.login_id','inner');
		//$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.c_id','inner');
		$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('item_id'=>$itemid));
		//$c=$qry->num_rows();
		return $qry->result();
	}
	function updateitem($itemstock,$price,$quantity,$measure,$date,$discription,$image,$itemid)
	{

		$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('item_id'=>$itemid));

		$this->db->where('item_id',$itemid);
		$this->db->update('tbl_item',array('price'=>$price,'quantity'=>$quantity,'measurement'=>$measure,'stock'=>$itemstock,'date'=>$date,'discription'=>$discription,'photo'=>$image));

	}
	//product slection
	function viewsnacks()
	{

		$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Biscuits','subcategory_name'=>'Sundried Tomatoes & Others','subcategory_name'=>'Dry Fruits & Nuts'));
		return $qry->result();
	}
	function Biscuits()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Biscuits',));
		return $qry->result();
	}
	function Cookies()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Cookies',));
		return $qry->result();
	}
	function Straws()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Straws',));
		return $qry->result();
	}
	function Olives()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Olives, Capers & Tapenades',));
		return $qry->result();
	}
	function Gherkins()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Gherkins & Jalapenos',));
		return $qry->result();
	}
	function Sundried()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Sundried Tomatoes & Others',));
		return $qry->result();
	}
	function Chips()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Chips , Nachos & Crisps',));
		return $qry->result();
	}

	function Dryfruits()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Dry Fruits & Nuts',));
		return $qry->result();
	}
	function Dryseeds()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Dry Seeds',));
		return $qry->result();
	}
	function DrySnacks()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Indian & Dry Snacks',));
		return $qry->result();
	}
	function Funsize()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Funsize Packs & Snacksize Bars',));
		return $qry->result();
	}
	function Milk()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Milk, Dark & Mint Chocolates',));
		return $qry->result();
	}
	function Fudge()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Fudge & Truffles',));
		return $qry->result();
	}
	function Bouquettes()
	{
	$this->db->join('tbl_subcategory','tbl_item.subcategory_id=tbl_subcategory.subcategory_id','inner');
		$this->db->join('tbl_category','tbl_subcategory.c_id=tbl_category.category_id','inner');
		$qry=$this->db->get_where('tbl_item',array('subcategory_name'=>'Gift Packs & Bouquettes',));
		return $qry->result();
	}
	function getsubcategory($catogryid)
	{
		 $response = array();
		$this->db->select('subcategory_id,subcategory_name');
		//$this->db->from('tbl_subcategory');
		$this->db->where('c_id',$catogryid);
		$q=$this->db->get('tbl_subcategory');
		$response = $q->result_array();
		return $response;


	}
	function view_singleproduct($itemid)
	{
		$qry=$this->db->get_where('tbl_item',array('item_id'=>$itemid));
		return $qry->result();

	}
	function addtocart($bookingdata)
	{
		$this->db->insert('tbl_booking',$bookingdata);


	}

	function displaycart($customerid)
	{
		$this->db->join('tbl_item','tbl_booking.product_id=tbl_item.item_id','inner');
		$qry=$this->db->get_where('tbl_booking',array('cust_id'=>$customerid,'booking_status'=>0));

		return $qry->result();
	}
	function displaybookeditems($customerid)
	{
		$this->db->join('tbl_item','tbl_booking.product_id=tbl_item.item_id','inner');
		$qry=$this->db->get_where('tbl_booking',array('cust_id'=>$customerid,'booking_status'=>1));
		return $qry->result();
	}
	function removebooking($bookingid)
	{

		$this->db->where('booking_id',$bookingid);
   $this->db->delete('tbl_booking');
	}
	function bookitem()
	{
		$this->db->join('tbl_item','tbl_booking.product_id=tbl_item.item_id','inner');


		$qry=$this->db->get_where('tbl_booking',array('booking_status'=>0));
		return $qry->result();
	}
	function useraddress($userid)
	{
		$this->db->join('tbl_login','tbl_booking.cust_id=tbl_login.login_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');
		$qry=$this->db->get_where('tbl_booking',array('cust_id'=>$userid));
		return $qry->result();
	}
	function checkorder($itemid)
	{
		$qry=$this->db->get_where('tbl_booking',array('product_id'=>$itemid,'booking_status'=>0));
		return $qry->result();
	}
	function updateqty($cid,$d,$cust_id)
	{

			   // returns the affected rows number, so it needs to be higher than 0, if any row was affected.
			$this->db->where(array('booking_id'=>$cid,'cust_id'=>$cust_id));

			$this->db->update('tbl_booking',$d);



	}
	function scount($a)
	{
		$qry=$this->db->get_where('tbl_sellerinfo',array('s_status'=>$a));
		$c=$qry->num_rows();
		return $c;
	}
	function categorycount($a)
	{
		$qry=$this->db->get_where('tbl_category',array('c_status'=>$a));
		$c=$qry->num_rows();
		return $c;
	}
	function subcategorycount($a)
	{
		$qry=$this->db->get_where('tbl_subcategory',array('sub_status'=>$a));
		$c=$qry->num_rows();
		return $c;
	}
	function customercount($a)
	{
		$qry=$this->db->get_where('tbl_login',array('type'=>$a));
		$c=$qry->num_rows();
		return $c;
	}
	function itemcount($username)
	{
		$qry=$this->db->get_where('tbl_item',array('ilogin_id'=>$username));
		$c=$qry->num_rows();
		return $c;
	}
	function wcategorycount($userid,$a)
	{
		$qry=$this->db->get_where('tbl_category',array('s_id'=>$userid,'c_status'=>$a));
		$c=$qry->num_rows();
		return $c;
	}
	function wsubcategorycount($userid,$a)
	{
		$qry=$this->db->get_where('tbl_subcategory',array('s_id'=>$userid,'sub_status'=>$a));
		$c=$qry->num_rows();
		return $c;
	}
	function cart($username,$a)
	{
		$qry=$this->db->get_where('tbl_booking',array('cust_id'=>$username,'booking_status'=>$a));
		$c=$qry->num_rows();
		return $c;
	}
	function Order($username,$a)
	{
		$qry=$this->db->get_where('tbl_booking',array('cust_id'=>$username,'booking_status'=>$a));
		$c=$qry->num_rows();
		return $c;
	}
	function updatebookingaddrres($data,$bid)
	{
		$this->db->where('booking_id', $bid);
        $this->db->update('tbl_booking', $data);
	}
	function userdeliveryaddress($bid)
	{
		$this->db->join('tbl_login','tbl_booking.cust_id=tbl_login.login_id','inner');
		$this->db->join('tbl_registration','tbl_login.user_id=tbl_registration.user_id','inner');
		$this->db->join('tbl_address','tbl_registration.address_id=tbl_address.address_id','inner');
		$this->db->join('tbl_district','tbl_address.district_id=tbl_district.district_id','inner');
		$qry=$this->db->get_where('tbl_booking',array('booking_id'=>$bid));
		return $qry->result();

	}

	function prodprice($prodid)
	{
		$this->db->select('price');
			$this->db->from('tbl_item');
			$this->db->where('item_id',$prodid);
	 $query = $this->db->get();
	 return $query->result();
	}
	public function ForgotPassword($email)
{
    $this->db->select('email');
    $this->db->from('tbl_login');
    $this->db->where('email', $email);
    $query=$this->db->get();
    return $query->row_array();
}
public function sendpassword($data)
{
    $email = $data['email'];
    $query1=$this->db->query("SELECT *  from tbl_login where email = '".$email."' ");
    $row=$query1->result_array();
    if ($query1->num_rows()>0)
{
        $passwordplain = "";
        $passwordplain  = rand(999999999,9999999999);
        $newpass['password'] = md5($passwordplain);
        $this->db->where('email', $email);
        $this->db->update('tbl_login', $newpass);
        $mail_message='Dear '.$row[0]['name'].','. "\r\n";
        $mail_message.='Thanks for contacting regarding to forgot password,<br> Your <b>Password</b> is <b>'.$passwordplain.'</b>'."\r\n";
        $mail_message.='<br>Please Update your password.';
        $mail_message.='<br>Thanks & Regards';
        $mail_message.='<br>Your company name';
        require 'PHPMailerAutoload.php';
        require 'class.phpmailer.php';
        $mail = new PHPMailer;
        $mail->IsSendmail();
        $mail->isSMTP();
        $mail->SMTPAuth = true;
        $mail->Host = "hostname";
        $subject = 'Testing Email';
        $mail->AddAddress($email);
        $mail->IsMail();
        $mail->From = 'admin@***.com';
        $mail->FromName = 'admin';
        $mail->IsHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $mail_message;
        $mail->Send();
        if (!$mail->send()) {

            echo "<script>alert('msg','Failed to send password, please try again!')</script>";
        } else {

            echo "<script>alert('msg','Password sent to your email!')</script>";
        }
        redirect(base_url().'Jobseeker/index','refresh');
    }
    else
    {

        echo "<script>alert('msg','Email not found try again!')</script>";
        redirect(base_url().'Jobseeker/index','refresh');
    }
}
function bankverification($data)
{
	$qry=$this->db->get_where('tbl_bank',$data);
	return $qry->result();
}
function select_id($bkid)
{
	$qry=$this->db->get_where('tbl_booking',array('booking_id'=>$bkid));
	return $qry->result();
}
function updatestatus($ordernumber)
{
	$this->db->where(array('ordernumber'=>$ordernumber));
	$this->db->update('tbl_booking',array('booking_status'=>1));
}
function updatebankbalance($balance,$bankid)
{
	$this->db->where('bank_id',$bankid);
	$this->db->update('tbl_bank',array('balance'=>$balance));
}
function updateorder($bkid,$cust_id)
{
	$this->db->where(array('booking_id'=>$bkid,'cust_id'=>$cust_id));
	$this->db->update('tbl_booking',array('ordernumber'=>2));
}
 function selectorganizer ($search) {
    $condition = "item_name = '" . $search . "'";
    $this->db->select('*');
    $this->db->from('tbl_item');
    $this->db->where($condition);
    $query = $this->db->get();
    return $query->result();

}
function selectorganizercategory ($search)
{

	$this->db->join('tbl_category','tbl_item.category_id=tbl_category.category_id','inner');
	$this->db->join('tbl_subcategory','tbl_category.category_id=tbl_subcategory.c_id','inner');
			//$condition = "category_name = '" . $search . "'";
	    $this->db->select('*');
	    $this->db->from('tbl_item');
	    $this->db->like('LOWER(category_name)', strtolower($search));
			 $this->db->or_like('LOWER(subcategory_name)', strtolower($search));
	    $query = $this->db->get();
	    return $query->result();
}
function selectproduct($bs_id)
{
	$qry=$this->db->get_where('tbl_item',array('item_id'=>$bs_id));
	return $qry->result();
}
function updatestock($updatedstock,$prodid)
{

	$this->db->where('item_id',$prodid);
	$this->db->update('tbl_item',array('stock'=>$updatedstock));
}
}
?>
